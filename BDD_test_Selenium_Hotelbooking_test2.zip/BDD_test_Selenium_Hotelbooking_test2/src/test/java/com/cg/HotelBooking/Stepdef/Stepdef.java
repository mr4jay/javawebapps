package com.cg.HotelBooking.Stepdef;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	
	By firstName;
	By lastName;
	By email;
	By mobileNumb;
	By submit;
	
	WebDriver driver;
	
	// runs before first "Given" case
	@Before
	public void init() {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver_1.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
	//runs after last "Then" case
	@After
	public void finish() throws Exception {
		// TODO Auto-generated method stub
		Thread.sleep(5000);
		driver.quit();

	}
		
	
	
	@Given("^HotelBooking page for validation$")
	public void hotelbooking_page_for_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		driver.navigate().to("file:///C:/Users/MKOTTEDA/Desktop/demo/BDD_test_Selenium_Hotelbooking_test2/webpages/hotelbooking.html");
		firstName=By.id("txtFirstName");//or use By.name,By.xpath etc...
		lastName = By.xpath("//*[@id=\"txtLastName\"]");//or use By.name,By.id,By.class etc...
		email = By.xpath("//*[@id=\"txtEmail\"]");
		mobileNumb = By.xpath("//*[@id=\"txtPhone\"]");
		submit = By.xpath("//*[@id=\"btnPayment\"]");
	}

	@When("^Enter submit without FirstName$")
	public void enter_submit_without_FirstName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		driver.findElement(submit).click();
		Thread.sleep(1000);
	}

	@Then("^Get alert with 'Please fill the First Name'$")
	public void get_alert_with_Please_fill_the_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@When("^Enter submit without entering lastname$")
	public void enter_submit_without_entering_lastname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@Then("^Get alert with 'Please fill the Last Name'$")
	public void get_alert_with_Please_fill_the_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@When("^Enter submit without entering email$")
	public void enter_submit_without_entering_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@Then("^Get alert with 'Please fill the Email'$")
	public void get_alert_with_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@When("^Enter submit with ivalid email$")
	public void enter_submit_with_ivalid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@Then("^Get alert with 'Please enter valid Email Id\\.'$")
	public void get_alert_with_Please_enter_valid_Email_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@When("^Enter submit without entering mobile number$")
	public void enter_submit_without_entering_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@Then("^Get alert with 'Please fill the Mobile No\\.'$")
	public void get_alert_with_Please_fill_the_Mobile_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@When("^Enter submit with ivalid mobile number$")
	public void enter_submit_with_ivalid_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@Then("^Get alert with 'Please enter valid Contact no\\.'$")
	public void get_alert_with_Please_enter_valid_Contact_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 
	}

}
