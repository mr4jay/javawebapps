package com.capg.boot;

import java.util.ArrayList;
import java.util.List;

import com.capg.model.Customer;
import com.capg.service.AccountServiceImplementation;
import com.capg.service.IAcccountService;
import com.capg.utill.AccountOperation;
import com.capg.view.UserInterface;

public final class MainClass {
	private static List customers=new ArrayList<Customer>();
	private static IAcccountService as=new AccountServiceImplementation();
	private static UserInterface ui=new UserInterface();
	private static int Idchoice;
private static	boolean flag=false;

	public static void main(String[] args) {
customers=(as.getallCustomer());

do
{
	Idchoice= ui.getCustomerdetalis(customers);
	flag=as.validateCustomerId(Idchoice); 
	if(flag==true)
	{
		ui.getCustomerdetalisOfChoice(Idchoice);
	}
}while(flag==false);
 
	}

}
