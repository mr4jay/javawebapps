package com.capg.model;

public class Address {
@Override
	public String toString() {
		return "" + addressid + "doorNo:" + doorNo + ", streetName:" + streetName + " City:"
				+ City + ", state:" + state + " pincode:" + pincode ;
	}
private int addressid;
private String doorNo;
private String streetName,City,state,pincode;
public Address(int addressid, String doorNo, String streetName, String city, String state, String pincode) {
	super();
	this.addressid = addressid;
	this.doorNo = doorNo;
	this.streetName = streetName;
	City = city;
	this.state = state;
	this.pincode = pincode;
}
public int getAddressid() {
	return addressid;
}
public void setAddressid(int addressid) {
	this.addressid = addressid;
}
public String getDoorNo() {
	return doorNo;
}
public void setDoorNo(String doorNo) {
	this.doorNo = doorNo;
}
public String getStreetName() {
	return streetName;
}
public void setStreetName(String streetName) {
	this.streetName = streetName;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getPincode() {
	return pincode;
}
public void setPincode(String pincode) {
	this.pincode = pincode;
}

}
