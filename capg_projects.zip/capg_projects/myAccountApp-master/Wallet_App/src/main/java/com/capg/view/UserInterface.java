package com.capg.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capg.dao.AccountDao;
import com.capg.dao.IAccount;
import com.capg.model.Customer;

public class UserInterface {

static Scanner sc=new Scanner(System.in);
IAccount ia=new AccountDao();
public int getCustomerdetalis(List<Customer> customers) {
	for (Customer cust:customers)
	System.out.println(cust);
	System.out.println("Enter valid CustomerId: \n");
return(sc.nextInt());	
}

public void getCustomerdetalisOfChoice(int idchoice) {

	for (Customer cust: ia.getallCustomer())
	{
		if(cust.getCustomerId()==idchoice)
		{
			System.out.println(cust);break;
		}
	}
}
}
