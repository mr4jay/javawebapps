package com.capg.dao;
import java.util.List;
import com.capg.model.Customer;
public interface IAccount {

	public List<Customer> getallCustomer();
	public boolean validateCustomerId(int customerId);
	
}
