package com.capg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capg.exception.CustomerNotFoundException;
import com.capg.model.Address;
import com.capg.model.Customer;

public class AccountDao implements IAccount {

	private static List<Customer> customers=new ArrayList<Customer>();
	@Override
	public  List<Customer> getallCustomer() {
		customers.add(new Customer(101,"Margavi","Reddy","7893896082","margo@gmail.com",LocalDate.of(1998,04,23),new Address(10,"2-17-5/4/A","prashanthi nagar","Secundrabad","Telangana","500039")));
		customers.add(new Customer(102,"Aishwarya","Reddy","724496082","aishu@gmail.com",LocalDate.of(1997,10,19),new Address(10,"2-17-5/4/A","Thirumalagiri","Regonda","Telangana","500069")));
		customers.add(new Customer(103,"Akankasha","Reddy","823745627","pandu@gmail.com",LocalDate.of(2000,06,16),new Address(10,"2-17-5/4/A","Karimnagar","Vavilalapally","Telangana","500001")));
		customers.add(new Customer(104,"Deepika","Reddy","784686452","deepu@gmail.com",LocalDate.of(1994,05,13),new Address(10,"2-17-5/4/A","Balasamudhram","Hanumakonda","Telangana","500035")));

		return customers;
	}

	@Override
	public boolean validateCustomerId(int customerId) {

		for(Customer customer:customers)
		{	
			if(customer.getCustomerId()==customerId)
		return true;
		else {
			try {
				throw new CustomerNotFoundException("\n*?No Customer Is Found with the Given ID?*\n");
			}catch(CustomerNotFoundException cn)
			{
				System.out.println(cn.getMessage());break;
			}
		}
	}
		return false;
	}


}


