package com.capg.service;

import java.util.List;

import com.capg.model.Customer;

public interface IAcccountService {
	public List<Customer> getallCustomer();
	public boolean validateCustomerId(int customerId);

}
