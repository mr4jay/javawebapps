
package com.capg.service;

import java.util.List;

import com.capg.dao.AccountDao;
import com.capg.dao.IAccount;
import com.capg.model.Customer;

public class AccountServiceImplementation implements IAcccountService{

	private static IAccount accontdao=new AccountDao();

	@Override
	public List<Customer> getallCustomer() {
		return accontdao.getallCustomer();
	}

	@Override
	public boolean validateCustomerId(int customerId) {
		return accontdao.validateCustomerId(customerId);
	}
	

}
