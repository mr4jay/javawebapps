package com.capg.utill;

public enum AccountOperation {
CREATE_ACCOUNT,TRANSACTION;
}
