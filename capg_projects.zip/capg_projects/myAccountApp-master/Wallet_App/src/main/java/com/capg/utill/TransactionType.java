package com.capg.utill;

public enum TransactionType {
WITHDRAW,DEPOSIT;
}
