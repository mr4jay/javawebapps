package com.capg.utill;

public enum AccountType {
	SAVINGS,CURRENT,FD,INSURANCE;
}
