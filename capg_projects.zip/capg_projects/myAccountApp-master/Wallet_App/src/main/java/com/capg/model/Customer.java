package com.capg.model;

import java.time.LocalDate;

public class Customer {
	private  int customerId;
	private  String firstName,LastName,phoneNumber,email;
	private  LocalDate dob;
	
	@Override
	public String toString() {
		return "customerId=" + customerId + " firstName=" + firstName + " LastName=" + LastName
				+ " phoneNumber=" + phoneNumber + " email=" + email + " DateOfBirth=" + dob + " address=" + address + "\n";
	}
	public Customer()
	{
		
	}
	public Customer(int customerId, String firstName, String lastName, String phoneNumber, String email, LocalDate dob,
			Address address) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		LastName = lastName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.dob = dob;
		this.address = address;
	}
	public  String getEmail() {
		return email;
	}
	public  void setEmail(String email) {
		this.email = email;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public  int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	private Address address;
	
}
