package com.capg.model;

import com.capg.utill.AccountType;

public class Account {
	private int accountId;
	private String AccountNo;
	private AccountType Accounttype;
	private Customer customer;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(String accountNo) {
		AccountNo = accountNo;
	}
	public AccountType getAccounttype() {
		return Accounttype;
	}
	public void setAccounttype(AccountType accounttype) {
		Accounttype = accounttype;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}
