package com.capg.main;

public class Address {
	private double addressId;
	private double doorNo;
	private String StreetNo;
	private String city;
	private double pincode;
	private String state;

}
