package com.capg.main;

import java.time.LocalDate;

import com.capg.util.Transactiontype;

public class Transaction {
	private double transactionId;
	private LocalDate transactionDate;
	private Transactiontype transactionType;
	private double amount;
	private String description;
	private Account fromAcc;
	private Account toAcc;

}
