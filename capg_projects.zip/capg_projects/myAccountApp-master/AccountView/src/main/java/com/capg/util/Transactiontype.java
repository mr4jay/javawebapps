package com.capg.util;

public enum Transactiontype {
	DEBIT,CREDIT;

}
