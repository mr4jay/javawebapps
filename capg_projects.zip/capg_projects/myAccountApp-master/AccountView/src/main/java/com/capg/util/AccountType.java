package com.capg.util;

public enum AccountType {
	SAVINGS,FD,CURRENT,ZEROBALANCE;

}
