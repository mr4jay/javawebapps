package com.capg.main;

import java.time.LocalDate;

public class Customer {
	private double custId;
	private String firstName;
	private String lastName;
	private double mobileNo;
	private String emailId;
	private LocalDate dateOfBirth;
	private Address address;

}
