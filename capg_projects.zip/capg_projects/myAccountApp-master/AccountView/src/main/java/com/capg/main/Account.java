package com.capg.main;

import java.time.LocalDate;

import com.capg.util.AccountType;

public class Account {
	private double accNo;
	private double openingBal;
	private AccountType acctype;
	private LocalDate openingDate;
	private String description;
	private Customer customer;

}
