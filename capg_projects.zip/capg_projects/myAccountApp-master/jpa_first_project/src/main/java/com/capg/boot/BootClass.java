package com.capg.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capg.model.*;

public class BootClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=
			 Persistence.createEntityManagerFactory("demodb");
		
		EntityManager entityManager=emf.createEntityManager();
				
		EntityTransaction transaction=
				entityManager.getTransaction();
		
		transaction.begin();
		
		Employee employee=new Employee(1003,"jack","Jerry");
		entityManager.persist(employee);
		
		transaction.commit();
		entityManager.close();
	}

}