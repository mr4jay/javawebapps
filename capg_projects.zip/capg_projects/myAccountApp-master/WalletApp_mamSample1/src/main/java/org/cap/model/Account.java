package org.cap.model;

import java.time.LocalDateTime;

import org.cap.util.AccountType;

public class Account {
	
	private long accountNo;
	private double openingBalance;
	private AccountType accountType;
	private LocalDateTime openingDate;
	private String description;
	private Customer customer;
	
	public Account() {
		
	}
	
	public Account(long accountNo, double openingBalance, AccountType accountType, LocalDateTime openingDate,
			String description, Customer customer) {
		super();
		this.accountNo = accountNo;
		this.openingBalance = openingBalance;
		this.accountType = accountType;
		this.openingDate = openingDate;
		this.description = description;
		this.customer = customer;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}
	public AccountType getAccountType() {
		return accountType;
	}
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}
	public LocalDateTime getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(LocalDateTime openingDate) {
		this.openingDate = openingDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	

}
