package org.cap.exception;

public class InvalidCustomerIdException extends Exception {

	public InvalidCustomerIdException(String msg) {
		super(msg);
	}
}
