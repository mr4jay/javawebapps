package org.cap.util;

public enum AccountType {
	SAVINGS(1), CURRENT(2), RD(3), FD(4), LOAN(5);
	
	private int value;
	
	private AccountType(int value) {
		this.value=value;
	}

	public int getValue() {
		return value;
	}


	
	
}
