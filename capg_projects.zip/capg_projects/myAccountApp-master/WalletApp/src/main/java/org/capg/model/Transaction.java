package org.capg.model;

import java.time.LocalDate;

public class Transaction {
	private double transactionId;
	private LocalDate transactionDate;
	private String transactionType;
	private double amount;
	private Account fromAcc;
	private Account toAcc;
	public Transaction(double transactionId, LocalDate transactionDate, String transactionType, double amount,
			Account fromAcc, Account toAcc) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.transactionType = transactionType;
		this.amount = amount;
		this.fromAcc = fromAcc;
		this.toAcc = toAcc;
	}
	public double getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(double transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Account getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(Account fromAcc) {
		this.fromAcc = fromAcc;
	}
	public Account getToAcc() {
		return toAcc;
	}
	public void setToAcc(Account toAcc) {
		this.toAcc = toAcc;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate
				+ ", transactionType=" + transactionType + ", amount=" + amount + ", fromAcc=" + fromAcc + ", toAcc="
				+ toAcc + "]";
		
	}
	
	
	

}
