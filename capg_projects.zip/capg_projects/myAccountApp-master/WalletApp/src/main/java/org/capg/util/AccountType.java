package org.capg.util;

public enum AccountType {
	SAVINGS,FD,CURRENT;

}
