package org.capg.boot;

import org.capg.services.AccountServices;
import org.capg.services.IAccountServices;
import org.capg.view.UserInterface;

public class Main {
	
	
	private static IAccountServices accServices = new AccountServices();
	private static UserInterface ui = new UserInterface();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		

	}

}
