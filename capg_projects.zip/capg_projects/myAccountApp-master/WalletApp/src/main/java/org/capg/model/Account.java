package org.capg.model;

import java.time.LocalDate;

public class Account {
	private double accNo;
	private double openingBal;
	private LocalDate openingDate;
	private String description;
	private Customer customer;
	
	
	
	
	public Account(double accNo, double openingBal, LocalDate openingDate, String description, Customer customer) {
		super();
		this.accNo = accNo;
		this.openingBal = openingBal;
		this.openingDate = openingDate;
		this.description = description;
		this.customer = customer;
	}
	
	
	public double getAccNo() {
		return accNo;
	}
	public void setAccNo(double accNo) {
		this.accNo = accNo;
	}
	public double getOpeningBal() {
		return openingBal;
	}
	public void setOpeningBal(double openingBal) {
		this.openingBal = openingBal;
	}
	public LocalDate getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	@Override
	public String toString() {
		return "Address [accNo=" + accNo + ", openingBal=" + openingBal + ", openingDate=" + openingDate
				+ ", description=" + description + ", customer=" + customer + "]";
	}
	
	

}
