package org.capg.view;

import java.util.List;
import java.util.Scanner;

import org.capg.model.Customer;
import org.capg.util.AccountType;

public class UserInterface {
	private static Scanner scan = new Scanner(System.in);
	
	public int chooseCustomer(List<Customer> customers) {
		for(Customer customer:(customers)) {
			System.out.println(customer);
		}
		int customerId = scan.nextInt();
		return customerId;
	}
	
	
	public int showMenue() {
		System.out.println("1.create Account \t 2.Transactions \t 3.Exit");
		int choose=scan.nextInt();
		return choose;
	}
	
	public int showSubmenue() {
		System.out.println("1.Debit \t 2.Credit \t 3.Fund Transfer \t 4.Print account Description");
		int subChoose=scan.nextInt();
		return subChoose;
	}
	
	public AccountType acctype() {
		
		
		return null;
		
	}

}
