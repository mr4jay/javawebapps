package org.capg.dao;


import java.time.LocalDate;
import java.util.List;

import org.capg.model.*;

public class AccountDao implements IAccountDao {
	private static List<Customer> customer = custData();
	
	private static List<Customer> custData(){
		
		customer.add(new Customer(100, "manoj", "k", 99890,LocalDate.of(1997, 9, 2)));
		customer.add(new Customer(101, "vikky", "l", 95690,LocalDate.of(1989, 7, 8)));
		customer.add(new Customer(102, "manoj", "m", 77990,LocalDate.of(1924, 6, 4)));
		customer.add(new Customer(103, "manoj", "n", 35490,LocalDate.of(1977, 2, 3)));
		
		return customer;
		
	}

	public List<Customer> getAllCustomer() {
		return customer;
	}

	public void setCustomer(List<Customer> customer) {
		AccountDao.customer = customer;
	}

	@Override
	public boolean validateCustomer(int custNo) {
		// TODO Auto-generated method stub
		for(Customer customers:customer) {
			if(customers.getCustNo()==custNo) {
				return true;
			}
		}
		return false;
	}
	

}
