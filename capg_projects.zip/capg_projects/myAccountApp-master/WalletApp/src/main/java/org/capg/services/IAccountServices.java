package org.capg.services;

import java.util.List;

import org.capg.model.Customer;

public interface IAccountServices {
	public List<Customer> getAllCustomer();
	public boolean validateCustomer(int custNo);
	public void createAccount();
	

}
