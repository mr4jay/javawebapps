package org.capg.services;

import java.util.List;

import org.capg.dao.AccountDao;
import org.capg.dao.IAccountDao;
import org.capg.model.Customer;

public class AccountServices implements IAccountServices {
	private static IAccountDao accDao = new AccountDao();

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return accDao.getAllCustomer();
	}

	@Override
	public boolean validateCustomer(int custNo) {
		// TODO Auto-generated method stub
		boolean accIsTrue=accDao.validateCustomer(custNo);
		return accIsTrue;
	}

	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		
	}

}
