package org.capg.model;

public class Address {
	private double addressId;
	private double doorNo;
	private double streetNo;
	private String city;
	private double pincode;
	private String state;
	public Address(double addressId, double doorNo, double streetNo, String city, double pincode, String state) {
		super();
		this.addressId = addressId;
		this.doorNo = doorNo;
		this.streetNo = streetNo;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
	}
	public double getAddressId() {
		return addressId;
	}
	public void setAddressId(double addressId) {
		this.addressId = addressId;
	}
	public double getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(double doorNo) {
		this.doorNo = doorNo;
	}
	public double getStreetNo() {
		return streetNo;
	}
	public void setStreetNo(double streetNo) {
		this.streetNo = streetNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public double getPincode() {
		return pincode;
	}
	public void setPincode(double pincode) {
		this.pincode = pincode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", doorNo=" + doorNo + ", streetNo=" + streetNo + ", city=" + city
				+ ", pincode=" + pincode + ", state=" + state + "]";
	}
	
	

}
