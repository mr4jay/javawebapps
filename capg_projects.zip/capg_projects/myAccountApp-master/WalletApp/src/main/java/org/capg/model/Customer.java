package org.capg.model;

import java.time.LocalDate;

public class Customer {
	private int custNo;
	private String custFirstName;
	private String custLastName;
	private double mobileNo;
	private LocalDate dateOfBirth;
	private Account Account;
	private Address address;
	
	
	
	public Customer(int custNo, String custFirstName, String custLastName, double mobileNo, LocalDate dateOfBirth,
			Address address) {
		super();
		this.custNo = custNo;
		this.custFirstName = custFirstName;
		this.custLastName = custLastName;
		this.mobileNo = mobileNo;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
	}




	public Customer(int custNo, String custFirstName, String custLastName, double mobileNo, LocalDate dateOfBirth) {
		super();
		this.custNo = custNo;
		this.custFirstName = custFirstName;
		this.custLastName = custLastName;
		this.mobileNo = mobileNo;
		this.dateOfBirth = dateOfBirth;
	}

	
	
	
	public Customer(int custNo, String custFirstName, String custLastName, double mobileNo, LocalDate dateOfBirth,
			org.capg.model.Account account, Address address) {
		super();
		this.custNo = custNo;
		this.custFirstName = custFirstName;
		this.custLastName = custLastName;
		this.mobileNo = mobileNo;
		this.dateOfBirth = dateOfBirth;
		Account = account;
		this.address = address;
	}
	
	
	

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	
	public int getCustNo() {
		return custNo;
	}

	public void setCustNo(int custNo) {
		this.custNo = custNo;
	}

	public String getCustFirstName() {
		return custFirstName;
	}

	public void setCustFirstName(String custFirstName) {
		this.custFirstName = custFirstName;
	}

	public String getCustLastName() {
		return custLastName;
	}

	public void setCustLastName(String custLastName) {
		this.custLastName = custLastName;
	}

	public double getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(double mobileNo) {
		this.mobileNo = mobileNo;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Account getAccount() {
		return Account;
	}

	public void setAccount(Account Account) {
		this.Account = Account;
	}

	@Override
	public String toString() {
		return "Customer [custNo=" + custNo + ", custFirstName=" + custFirstName + ", custLastName=" + custLastName
				+ ", mobileNo=" + mobileNo + ", dateOfBirth=" + dateOfBirth + ", Account=" + Account + "]";
	}
	
	
	
	
	
	
}
