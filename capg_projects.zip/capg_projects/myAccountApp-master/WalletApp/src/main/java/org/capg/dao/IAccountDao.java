package org.capg.dao;


import java.util.List;

import org.capg.model.*;

public interface IAccountDao {
	//public List<Customer> getCustomer();
	public boolean validateCustomer(int custNo);
	public List<Customer> getAllCustomer();
	
}
