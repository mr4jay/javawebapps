package org.cap.dao;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface ICustomerDao {

	public boolean createCustomer(Customer customer);

	public boolean isValidLogin(Customer customer);
	
	public Customer findCustomer(String emaild);
	
	public Account createAccount(Account account);
	public Customer findCustomerById(int customerId);
}
