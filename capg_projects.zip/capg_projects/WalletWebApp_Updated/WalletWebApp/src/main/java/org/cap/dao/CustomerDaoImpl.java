package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Customer;

public class CustomerDaoImpl implements ICustomerDao {

	@Override
	public boolean createCustomer(Customer customer) {
		
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			entityManager.persist(customer.getAddress());
			entityManager.persist(customer);
		
		transaction.commit();
		entityManager.close();
		
		if(customer.getCustomerId()>0)
			return true;
		return false;
	}

	
	private EntityManager getEntityManager() {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("jpademo");
		return emf.createEntityManager();
	}


	@Override
	public boolean isValidLogin(Customer customer) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		String sql="from Customer c where c.emailId=:email and c.custPassword=:custPwd";
		
		Query query= entityManager.createQuery(sql);
		query.setParameter("email", customer.getEmailId());
		query.setParameter("custPwd", customer.getCustPassword());
		
		List<Customer> customers= query.getResultList();
		
		transaction.commit();
		entityManager.close();
		
		if(customers.size()>0)
			return true;
		else
			return false;
	}


	@Override
	public Customer findCustomer(String emaild) {

		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			String sql="from Customer c where c.emailId=:email";
			Query query= entityManager.createQuery(sql);
			query.setParameter("email", emaild);
			List<Customer> customers= query.getResultList();
			
			
		transaction.commit();
		entityManager.close();
		
		if(customers.size()>0)
			return customers.get(0);
		
		return null;
	}


	@Override
	public Account createAccount(Account account) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			entityManager.persist(account);
		transaction.commit();
		entityManager.close();
		if(account.getAccountNo()>0)
			return account;
		else
			return null;
	}


	@Override
	public Customer findCustomerById(int customerId) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			Customer customer= entityManager.find(Customer.class, customerId);
		transaction.commit();
		entityManager.close();
		return customer;
	}
}
