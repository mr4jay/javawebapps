package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface ICustomerService {
	public boolean createCustomer(Customer customer);

	public boolean isValidLogin(Customer customer);
	public Customer findCustomer(String emaild);
	public Account createAccount(Account account);
	public Customer findCustomerById(int customerId);
	
	public List<Account> findAccountsByCustomerId(int customerId);
}
