package org.cap.service;

import java.util.List;

import org.cap.dao.CustomerDaoImpl;
import org.cap.dao.ICustomerDao;
import org.cap.model.Account;
import org.cap.model.Customer;

public class CustomerServiceImpl implements ICustomerService {

	private ICustomerDao customerDao;
	
	public CustomerServiceImpl() {
		customerDao=new CustomerDaoImpl();
	}
	
	@Override
	public boolean createCustomer(Customer customer) {
		
		return customerDao.createCustomer(customer);
	}

	@Override
	public boolean isValidLogin(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.isValidLogin(customer);
	}

	@Override
	public Customer findCustomer(String emaild) {
		// TODO Auto-generated method stub
		return customerDao.findCustomer(emaild);
	}

	@Override
	public Account createAccount(Account account) {
		// TODO Auto-generated method stub
		return customerDao.createAccount(account);
	}

	@Override
	public Customer findCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.findCustomerById(customerId);
	}

	@Override
	public List<Account> findAccountsByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.findAccountsByCustomerId(customerId);
	}

}
