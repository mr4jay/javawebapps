package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.Response;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;
import org.cap.util.Utility;

/**
 * Servlet implementation class WithdrawlOrDeposite
 */
@WebServlet("/WithdrawlOrDeposite")
public class WithdrawOrDeposite extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ICustomerService customerService;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 PrintWriter out = response.getWriter();
		String accountType=request.getParameter("WithdrawlOrDeposite");
		String balance=request.getParameter("Amount");
		
		String description=request.getParameter("description");
		
		customerService=new CustomerServiceImpl();
		
		/*
		 * Account account=new Account();
		 * account.setAccountType(Utility.findAccountType(accountType));
		 * account.setOpeningBalance(Double.parseDouble(balance));
		 * account.setDescription(description);
		 * account.setOpeningDate(LocalDateTime.now());
		 * 
		 */	HttpSession session= request.getSession(false);
		Integer custId=Integer.parseInt(session.getAttribute("custId").toString());
		
		List<Account> accounts = customerService.findAccountsByCustomerId(custId);
		
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>Capg Bank</title>\r\n" + 
				"<link href=\"../css/mainPage.css\" rel=\"stylesheet\" type=\"text/css\">\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<form method=\"post\" action=\"../AccountCreationServlet\">\r\n" + 
				"<div id=\"accCnt\">\r\n" + 
				"<h3 align=\"center\" style=\"color:blue;\">Create Your Account</h3>\r\n" + 
				"<table>\r\n" + 
				"	<tr>\r\n" + 
				"		<td>Choose Account type:</td>\r\n" + 
				"		<td>\r\n" + 
				"			<select name=\"WithdrawlOrDeposite\">\r\n" + 
				"				<option value=\"Savings\">Withdraw</option>\r\n" + 
				"				<option value=\"Current\">Deposit</option>\r\n" + 
				"			</select>\r\n" + 
				"		</td>\r\n" + 
				"	</tr>	\r\n" + 
				"	<tr>\r\n" + 
				"		<td>Enter Amount:</td>\r\n" + 
				"		<td>\r\n" + 
				"			<input type=\"text\" name=\"Amount\" size=\"20\">\r\n" + 
				"		</td>\r\n" + 
				"	</tr>\r\n" + 
				"	\r\n" + 
				"	<tr>\r\n" + 
				"		<td>Description:</td>\r\n" + 
				"		<td>\r\n" + 
				"			<input type=\"text\" name=\"description\" size=\"20\">\r\n" + 
				"		</td>\r\n" + 
				"	</tr>\r\n" + 
				"	<tr>\r\n" + 
				"		<td></td>\r\n" + 
				"		<td>\r\n" + 
				"			<input type=\"submit\" value=\"Create Account\" class=\"btnClass\">\r\n" + 
				"		</td>\r\n" + 
				"	</tr>\r\n" + 
				"</table>\r\n" + 
				"\r\n" + 
				"</div>\r\n" + 
				"</form>\r\n" + 
				"</body>\r\n" + 
				"</html>");
		
		
		  Customer customer=customerService.findCustomerById(custId);
		  account.setCustomer(customer);
		  
		  Account account2=customerService.createAccount(account); 
		  if(account2 !=null)
		  request.getRequestDispatcher("pages/WithdrawOrDeposite.html").forward(request,response);
		  
		
	}

}
