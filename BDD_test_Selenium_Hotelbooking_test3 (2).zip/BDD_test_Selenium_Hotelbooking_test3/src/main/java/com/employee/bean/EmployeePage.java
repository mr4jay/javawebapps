package com.employee.bean;

import java.util.List;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


public class EmployeePage 
{
	
	@FindBy(how=How.ID,id="txtFirstName")
	WebElement firstName;
	
	@FindBy(how=How.ID,id="txtLastName")
	WebElement lastName;
	
	@FindBy(how=How.ID,id="txtEmail")
	WebElement email;
	
	@FindBy(how=How.ID,id="txtPhone")
	WebElement contact;
	
	@FindBy(how=How.ID,id="txtAddress1")
	WebElement addLineOne;
	
	@FindBy(how=How.ID,id="txtAddress2")
	WebElement addLineTwo;
	
	@FindBy(how=How.NAME,name="city")
	WebElement city;
	
	@FindBy(how=How.NAME,name="state")
	WebElement state;
	
	@FindBy(how=How.NAME,name="sector")
	List<WebElement> sector;
	
	@FindBy(how=How.NAME,name="fnm")
	WebElement fnm;
	
	@FindBy(how=How.XPATH,xpath="/html/body/form/table/tbody/tr[13]/td/a")
	WebElement myLink;
	
	
	public void clickLink()
	{
		this.myLink.click();
	}

	public void setSector(int sector) {
		this.sector.get(sector).click();
	}
	public void setFnm(String fnm) {
		this.fnm.sendKeys(fnm);
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);
	}
	public void setContact(String contact) {
		this.contact.clear();
		this.contact.sendKeys(contact);
	}
	public void setAddLineOne(String addLineOne) {
		this.addLineOne.sendKeys(addLineOne);
	}
	public void setAddLineTwo(String addLineTwo) {
		this.addLineTwo.sendKeys(addLineTwo);
	}
	public void setCity(String city) {
		this.city.sendKeys(city);
	}
	public void setState(String state) {
		this.state.sendKeys(state);
	}
	
}
