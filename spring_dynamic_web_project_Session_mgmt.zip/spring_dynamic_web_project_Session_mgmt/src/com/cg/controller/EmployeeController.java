package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.SessionMgmt;
import com.cg.service.ISessionMgmtService;


@Controller
public class EmployeeController {
	
	@Autowired
	ISessionMgmtService sessionMgmtService;
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveSessionMgmt(@ModelAttribute("sessionMgmt") SessionMgmt sessionMgmt, Model model) {
		
		sessionMgmt = sessionMgmtService.save(sessionMgmt);
		model.addAttribute("message","EmployeeId with Id"+sessionMgmt.getName()+"added Successfully");
		return "redirect:/index.html";
		
	}
	
	@RequestMapping("/index")
	public String getHomePage(Model model) {
		model.addAttribute("MgmtList", sessionMgmtService.loadAll());
		/*model.addAttribute("designation",new String[] {"System Associate","Asst Manager",
				"Dy Manager","Manager"});*/
		model.addAttribute("sessionMgmt",new SessionMgmt());
		return "index";
		
	}
	
	@RequestMapping("/success")
	public String redirect(@RequestParam("name") String name, Model model) {
		
		model.addAttribute("name",name);
		
		return "success";
	}

}
