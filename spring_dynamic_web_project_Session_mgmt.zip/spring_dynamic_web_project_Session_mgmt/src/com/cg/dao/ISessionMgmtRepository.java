package com.cg.dao;

import java.util.List;

import com.cg.entities.SessionMgmt;



public interface ISessionMgmtRepository {
	
	public abstract SessionMgmt save(SessionMgmt sessionMgmt);
	public abstract List<SessionMgmt> loadAll();

}
