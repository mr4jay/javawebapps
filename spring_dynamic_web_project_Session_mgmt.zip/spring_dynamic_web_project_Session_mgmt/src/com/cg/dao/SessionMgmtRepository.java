package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.SessionMgmt;




@Repository
public class SessionMgmtRepository implements ISessionMgmtRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public SessionMgmt save(SessionMgmt sessionMgmt) {
		// TODO Auto-generated method stub
		entityManager.persist(sessionMgmt);
		entityManager.flush();
		return sessionMgmt;
	}

	@Override
	public List<SessionMgmt> loadAll() {
		// TODO Auto-generated method stub
		TypedQuery<SessionMgmt> query =  entityManager.createQuery("select s from SessionMgmt s" ,SessionMgmt.class);
		return query.getResultList();
	}
	
	

}
