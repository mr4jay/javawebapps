package com.cg.service;

import java.util.List;

import com.cg.entities.SessionMgmt;



public interface ISessionMgmtService {
	
	public abstract SessionMgmt save(SessionMgmt sessionMgmt);
	public abstract List<SessionMgmt> loadAll();
	

}
