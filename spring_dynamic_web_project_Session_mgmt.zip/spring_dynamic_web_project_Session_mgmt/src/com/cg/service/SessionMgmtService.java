package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ISessionMgmtRepository;
import com.cg.entities.SessionMgmt;



@Service
@Transactional
public class SessionMgmtService implements ISessionMgmtService {
	
	@Autowired
	ISessionMgmtRepository sessionMgmtRepository ;
	
	
	
	@Override
	public SessionMgmt save(SessionMgmt employee) {
		// TODO Auto-generated method stub
		
		
		return sessionMgmtRepository.save(employee);
	}
	
	@Override
	public List<SessionMgmt> loadAll() {
		// TODO Auto-generated method stub
		
		
		return sessionMgmtRepository.loadAll();
	}
	

}
