package models;
import java.util.Comparator;
public class Product{
private String product_id;
private String product;
private String model;
private String manufacturer;
private String type_code;
private String loc_code;
private float msrp;
private float unit_cost;
private float disc_rate;
private int qty;

public String getProduct_id() {
	return product_id;
}
public void setProduct_id(String product_id) {
	this.product_id = product_id;
}
public String getProduct() {
	return product;
}
public void setProduct(String product) {
	this.product = product;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public String getManufacturer() {
	return manufacturer;
}
public void setManufacturer(String manufacturer) {
	this.manufacturer = manufacturer;
}
public String getType_code() {
	return type_code;
}
public void setType_code(String type_code) {
	this.type_code = type_code;
}
public String getLoc_code() {
	return loc_code;
}
public void setLoc_code(String loc_code) {
	this.loc_code = loc_code;
}
public float getMsrp() {
	return msrp;
}
public void setMsrp(float msrp) {
	this.msrp = msrp;
	this.unit_cost = msrp - this.disc_rate*msrp;
}
public float getUnit_cost() {
	return unit_cost;
}
//public void setUnit_cost(float unit_cost) {
//	this.unit_cost = unit_cost;
//}
public float getDisc_rate() {
	return disc_rate;
}

public void setDisc_rate(float disc_rate) {
	this.disc_rate = disc_rate;
	this.unit_cost = this.msrp - disc_rate*0.01f*this.msrp;
}
public int getQty() {
	return qty;
}
public void setQty(int qty) {
	this.qty = qty;
}
public Product(String product_id, String product, String model, String manufacturer, String type_code, String loc_code,
		float msrp, float unit_cost, float disc_rate, int qty) {
	super();
	this.product_id = product_id;
	this.product = product;
	this.model = model;
	this.manufacturer = manufacturer;
	this.type_code = type_code;
	this.loc_code = loc_code;
	this.msrp = msrp;
	this.unit_cost = msrp - msrp*0.01f*disc_rate;
	this.disc_rate = disc_rate;
	this.qty = qty;
	
	
}

public String getCompString(String order)
{
	if(order.equals("default"))
		order="1,2,3,4,5,6,7,8,9,10";
	String[] keys = order.split(",");
	String compositeKey = "";
	for(int i =0; i<keys.length;i++)
	{	
	
		switch(Integer.parseInt(keys[i]))
		{
		case 1 : compositeKey+=this.product_id;break;
		case 2 : compositeKey+=this.product;break;
		case 3 : compositeKey+=this.model;break;
		case 4 : compositeKey+=this.manufacturer;break;
		case 5 : compositeKey+=this.type_code;break;
		case 6 : compositeKey+=this.loc_code;break;
		case 7 : compositeKey+=Float.toString(this.msrp);break;
		case 8 : compositeKey+=Float.toString(this.unit_cost);break;
		case 9 : compositeKey+=Float.toString(this.disc_rate);break;
		case 10 : compositeKey+=Integer.toString(this.qty);break;
		
		}
	compositeKey+=",";
	}
	return compositeKey;
}
public void PrintProduct(String order)
{
	if(order.equals("default"))
		order="1,2,3,4,5,6,7,8,9,10";
	String[] keys = order.split(",");
	String compositeKey = "";
	for(int i =0; i<keys.length;i++)
	{	
	
		switch(Integer.parseInt(keys[i]))
		{
		case 1 : compositeKey+=this.product_id;break;
		case 2 : compositeKey+=this.product;break;
		case 3 : compositeKey+=this.model;break;
		case 4 : compositeKey+=this.manufacturer;break;
		case 5 : compositeKey+=this.type_code;break;
		case 6 : compositeKey+=this.loc_code;break;
		case 7 : compositeKey+=Float.toString(this.msrp);break;
		case 8 : compositeKey+=Float.toString(this.unit_cost);break;
		case 9 : compositeKey+=Float.toString(this.disc_rate);break;
		case 10 : compositeKey+=Integer.toString(this.qty);break;
		
		}
	compositeKey+="	";
	}
	System.out.println(compositeKey);
	
}

}


