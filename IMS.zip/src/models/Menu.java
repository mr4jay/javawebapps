package models;

import java.util.ResourceBundle;

public class Menu {
	
public void printSubMenu(String[] subMenu,ResourceBundle messages){
	System.out.println(messages.getString(subMenu[0]));
	for (int i=1;i<subMenu.length;i++)
	{
		System.out.println(" "+(i)+". "+messages.getString(subMenu[i]));
	}
}
}
