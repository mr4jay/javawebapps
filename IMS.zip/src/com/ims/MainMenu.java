package com.ims;

import java.util.Collections;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;

import helpers.helper;
import menus.menu1;
import menus.menu2;
import menus.menu4;
import menus.menu3;
import models.Menu;
import models.Product;

public class MainMenu extends Menu {
	public MainMenu() {
		super();
	}

	String[] subMenu = { "Input_Data" };

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		String name = "helpers.languages_en";
		ResourceBundle messages = ResourceBundle.getBundle(name);
		System.out.println("Welcome to 2 Day Inventory Management System : ");
		ArrayList<Product> InputData = new ArrayList();
		menu1 menu1 = new menu1();
		menu2 menu2 = new menu2();
		menu3 menu3 = new menu3();
		menu4 menu4 = new menu4();
		while (true) {
			System.out.print(messages.getString("SelectOption"));
			int option =0;
			System.out.println(
					" \n 1.Input Data \n 2.Search \n 3.Show Inventory \n 4.Change Record \n 7.Exit");
			try {
				option = sc.nextInt();
			} catch (Exception e) {
				sc.nextLine();
			}
			switch (option) {
			default :
				System.out.println(messages.getString("select_below"));
				break;
			case 1:
				InputData = menu1.readInputData(InputData, messages);
				Collections.sort(InputData, helper.compareById);
				break;
			case 2:
				menu2.menu2_search(InputData, messages);
				break;
			case 3:
				menu3.menu3_show(InputData, messages);
				break;
			case 4:
				menu4.menu4_change(InputData, messages);
				break;
			case 7:
				helper.writetoFile(InputData, "default");
				System.exit(0);
			}

		}
	}
}
