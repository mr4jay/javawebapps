//menu 3 :Show products
package menus;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;
import java.util.Scanner;
import models.Menu;
import models.Product;
import helpers.helper;

public class menu3 extends Menu {//menu 3 class
		public menu3() {
			super();
		}

	public void menu3_show(ArrayList<Product> InputData, ResourceBundle message) {
		//method to show products categorized based on parameters like product ID,product,manufacturer etc.
		//precondition:product ID is unique in the inventory system
		Scanner sc = new Scanner(System.in);
		String[] subMenu = { "Menu3submenu1", "Menu3submenu2", "Menu3submenu3","Menu3submenu4","Menu3submenu5","Menu3submenu6","Menu3submenu7", "Main_Menu" };
		String[] Man_nm= {"0"};
		String[] type_nm= {"0"};
		String[] Loc_nm= {"0"};
		String[] Mod_nm= {"0"};
		Boolean exitmenu_3 = false;
		while (exitmenu_3 != true) {
			super.printSubMenu(subMenu, message);
			//printing sub menu to specify the display category
			int menu3opt = 0;
			try {//exception try block
				menu3opt = sc.nextInt();
			} catch (Exception e) {
				sc.nextLine();//to handle invalid input values
			}
			int[] count = { 0 };
			switch (menu3opt) {//sub menu logic
			
			case 1:
				//Displaying all products in inventory
				System.out.println(message.getString("Menu3displayall"));
				System.out.println(helper.PrintHeader("default", " "));	
				//printing header
				Collections.sort(InputData, helper.compareByProduct.thenComparing(helper.compareByManufacturer).thenComparing(helper.compareByModel).thenComparing(helper.compareById));
				//sorting all the records by product,manufacturer,model and product ID
				InputData.forEach(Product -> {

					Product.PrintProduct("default");//printing all the records
				});
				break;
				
			case 2:
				//Displaying all products in inventory by Manufacturer name
				System.out.println(message.getString("Menu3displayman"));
				Collections.sort(InputData, helper.compareByManufacturer.thenComparing(helper.compareByProduct).thenComparing(helper.compareByModel).thenComparing(helper.compareById));
				//sorting all the records by Manufacturer
				
				InputData.forEach(Product -> {
				
					if (!Man_nm[0].equals(Product.getManufacturer()))
						//to display the unique manufacturer name before printing all the records for that manufacturer
							{
					System.out.println("Manufacturer name:"+Product.getManufacturer());
					//printing each manufacturer name 
					System.out.println(helper.PrintHeader("default", " "));
					//printing header
				
					Man_nm[0]=Product.getManufacturer();
							}
					
					Product.PrintProduct("default");
					//printing product records
				});
				break;
			
			case 3:
				//Displaying all products in inventory by Type
				System.out.println(message.getString("Menu3displaytyp"));
				Collections.sort(InputData, helper.compareByType.thenComparing(helper.compareByProduct).thenComparing(helper.compareByModel).thenComparing(helper.compareByManufacturer).thenComparing(helper.compareById));
				//sorting all records by type,product,model,manufacturer and product ID
				InputData.forEach(Product -> {
					if (!type_nm[0].equals(Product.getType_code()))
						//to display the unique type code value before printing all the records for that type code
					{
						System.out.println("Type code:"+Product.getType_code());
						//printing each unique Type code value
						System.out.println(helper.PrintHeader("default", " "));
						//printing header
						
						type_nm[0]=Product.getType_code();
					}
					
					Product.PrintProduct("default");
					//printing product records
				});
				break;

			case 4:
				//Displaying all products in inventory by Location
				System.out.println(message.getString("Menu3displayloc"));
				Collections.sort(InputData, helper.compareByLocation.thenComparing(helper.compareByProduct).thenComparing(helper.compareByModel).thenComparing(helper.compareByManufacturer).thenComparing(helper.compareById));
				//sorting all records by Location,product,model,manufacturer and product ID
				InputData.forEach(Product -> {
					if (!Loc_nm[0].equals(Product.getLoc_code()))
						//to display the unique Location code value before printing all the records for that Location code
					{
						System.out.println("Location code:"+Product.getLoc_code());
						//printing each unique Location code value
						System.out.println(helper.PrintHeader("default", " "));
						//printing header
						Loc_nm[0]=Product.getLoc_code();
					}
					
					Product.PrintProduct("default");
					//printing product records
				});
				break;
			
			case 5:
				//Displaying all products in inventory by Discount rate -both ascending and descending order
				System.out.println(message.getString("Menu3displaydis"));
				System.out.println(message.getString("Menu3displaydis1"));
				String Ordertype = sc.next();
				Collections.sort(InputData, helper.compareByDiscount.thenComparing(helper.compareById));
				//sorting records in ascending order of discount rate and product ID
				if (Ordertype.equals("2")) {
					Collections.reverse(InputData);
					//sorting records in descending order of discount rate
				}
				System.out.println(helper.PrintHeader("default", " "));
				//printing header
				InputData.forEach(Product -> {
					if (Product.getDisc_rate() > 0) {
						//printing all records with discount rate
						
						Product.PrintProduct("default");
						//printing product records
					}
				});
				break;
			
			case 6:
				//Displaying all products in inventory by Model
				System.out.println(message.getString("Menu3displaymod"));
				Collections.sort(InputData, helper.compareByModel.thenComparing(helper.compareByProduct).thenComparing(helper.compareByManufacturer).thenComparing(helper.compareById));
				//sorting all records by Model,product,manufacturer and product ID
				InputData.forEach(Product -> {
					if (!Mod_nm[0].equals(Product.getModel()))
						//to display the unique model value before printing all the records for that Model
					{
						System.out.println("Model:"+Product.getModel());
						//printing each Model value
						System.out.println(helper.PrintHeader("default", " "));
						//printing header
						Mod_nm[0]=Product.getModel();
					}
			
					Product.PrintProduct("default");
					//printing product records
				});
				break;

			case 7:
				//option to return back to main menu
				exitmenu_3 = true;
				break;
			
			}
		}
	}
}