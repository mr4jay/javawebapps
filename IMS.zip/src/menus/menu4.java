
package menus;

import java.util.*;

import helpers.helper;
import models.Menu;
import models.Product;

public class menu4 extends Menu {
	public menu4() {
		super();
	}

	String[] subMenu = { "Menu4", "AddRecord", "DeleteRecord", "ModifyRecord", "Main_Menu" };

	public void menu4_change(ArrayList<Product> InputData, ResourceBundle message) {
		Scanner sc = new Scanner(System.in);

		Boolean exitmenu_4 = false;
		// ******************************************************************
		final int product_exists[] = new int[1];
		final String product_ID[] = new String[1];
		final String location_code[] = new String[1];
		while (exitmenu_4 != true) {
			super.printSubMenu(subMenu, message);
			int menu4opt = 0;
			try {
				menu4opt = sc.nextInt();
			} catch (Exception e) {
				sc.nextLine();
			}
			switch (menu4opt) {
			case 1:
				product_exists[0] = 0;

				while (true) {
					sc.nextLine();
					System.out.println("\n Enter the Product ID [of length 10]:");
					product_ID[0] = sc.nextLine();
					if (product_ID[0].length() <= 10) {
						break;
					}
				}

				while (true) {
					System.out.println("\n Enter the Location Code [of length 3]:\n");
					location_code[0] = sc.nextLine();
					if (location_code[0].length() <= 3) {
						break;
					}
				}

				// Checking if the product already exists
				InputData.forEach(Product->{
					if(product_ID[0].equals(Product.getProduct_id())) 
					{
						if(location_code[0].equals(Product.getLoc_code())) 
						{
							product_exists[0] = 1;
							System.out.println("The entry already exists. Do you want to update the quantity? <1/0)>");

							System.out.println("\n Product ID:" + Product.getProduct_id() + "\t Product:"
									+ Product.getProduct() + "\t Model:" + Product.getModel() + "\t Manufacturer:"
									+ Product.getManufacturer() + "\t Type code:" + Product.getType_code()
									+ "\t Location code:" + Product.getLoc_code() + "\t MSRP:" + Product.getMsrp()
									+ "\t Unit Cost:" + Product.getUnit_cost() + "\t Discount Rate:"
									+ Product.getDisc_rate() + "\t Stock Quantity:" + Product.getQty());
							System.out.println("Choice: ");
							int choice = sc.nextInt();
							if (choice == 1) {
								System.out.println("Enter the quantity value to be added: ");
								int quant = sc.nextInt();
								int new_quant = Product.getQty() + quant;
								Product.setQty(new_quant);
							}
							System.out.println("---------------------------------");
						}
					}
				});

				if (product_exists[0] == 0) {
					String product = "";
					while (true) {
						System.out.println("\n Enter the Product [of length 20]:\n");
						product = sc.nextLine();
						if (product.length() <= 20) {
							break;
						}
					}

					String model = "";
					while (true) {
						System.out.println("\n Enter the Model [of length 10]:\n");
						model = sc.nextLine();
						if (model.length() <= 10) {
							break;
						}
					}

					String manufacturer = "";
					while (true) {
						System.out.println("\n Enter the Manuacturer [of length 20]:\n");
						manufacturer = sc.nextLine();
						if (manufacturer.length() <= 20) {
							break;
						}
					}

					String type_code = "";
					while (true) {
						System.out.println("\n Enter the Type Code [of length 3]:\n");
						type_code = sc.nextLine();
						if (type_code.length() <= 3) {
							break;
						}
					}

					System.out.println("\n Enter the MSRP :\n");
					float msrp = sc.nextFloat();

					float discount_rate = 0;
					while (true) {
						System.out.println("\n Enter the Discount Rate between 0 and 100:\n");
						discount_rate = sc.nextFloat();
						if (discount_rate >= 0 && discount_rate < 100) {
							break;
						}
					}

					int stock_quantity = 0;
					while (true) {
						System.out.println("\n Enter the Stock Quantity [>0]:\n");
						stock_quantity = sc.nextInt();
						if (stock_quantity >= 0) {
							break;
						}
					}

					Product objt = new Product(product_ID[0], product, model, manufacturer, type_code, location_code[0],
							msrp, 0, discount_rate, stock_quantity);
					InputData.add(objt); // Adding it to the list
					System.out.println("\nNew product added.");
				}
				break;
			case 2:
				product_exists[0] = 0;
				int product_counter[] = new int[2];
				product_counter[0] = 0; // track the number of product entries
										// it has searched
				product_counter[1] = 0; // save the entry number that matches
										// with the input query
				System.out.println("\n Enter the Product ID : \n");
				String Searchval_ID = sc.next();
				System.out.println("\n Enter the Location Code :\n");
				String Searchval_Loc_ = sc.nextLine();
				String Searchval_Loc = sc.nextLine();
				System.out.println("\n Searching for the particular entry : " + Searchval_ID + " At " + Searchval_Loc);
				InputData.forEach(Product -> {
					product_counter[0] = product_counter[0] + 1;
					if (Searchval_ID.equals(Product.getProduct_id())) {
						if (Searchval_Loc.equals(Product.getLoc_code())) {
							System.out.println("---------------------------------");
							// remove product code - test this
							// Product.remove(this);
							product_counter[1] = product_counter[0];
							product_exists[0] = 1;
						}
					}
				});
				if (product_exists[0] == 0) {
					System.out.println("No such product found.");
				} else {
					InputData.remove(product_counter[1] - 1);
					System.out.println("Selected Product deleted");

				}
				break;
			case 3:
				System.out.println("\n Enter the Product ID : \n");
				String Searchval_PID = sc.next();
				System.out.println("\n Enter the Location Code :\n");
				sc.nextLine();
				String Searchval_Location = sc.nextLine();
				System.out.println("\n Searching for the particular entry : " + Searchval_PID);
				InputData.forEach(Product -> {
					if (Searchval_PID.equals(Product.getProduct_id())) {
						if (Searchval_Location.equals(Product.getLoc_code())) {
							System.out.println("---------------------------------");
							System.out.println("\n Product ID:" + Product.getProduct_id() + "\t Product:"
									+ Product.getProduct() + "\t Model:" + Product.getModel() + "\t Manufacturer:"
									+ Product.getManufacturer() + "\t Type code:" + Product.getType_code()
									+ "\t Location code:" + Product.getLoc_code() + "\t MSRP:" + Product.getMsrp()
									+ "\t Unit Cost:" + Product.getUnit_cost() + "\t Discount Rate:"
									+ Product.getDisc_rate() + "\t Stock Quantity:" + Product.getQty());
							System.out.println("---------------------------------");

							System.out.println("Which attribute would you like to modify: ");
							System.out.println(
									"\n Product ID - 1 \n Product - 2 \n Model - 3 \n Manufacturer - 4 \n Type code - 5 \n Location code - 6 \n MSRP - 7 \n Unit Cost - 8 \n Discount Rate - 9 \n Stock Quantity - 10");
							System.out.println("Your Choice (Enter number): ");
							int choice = sc.nextInt();
							switch (choice) {
							case 1:
								String pID = "";
								while (true) {
									System.out.println("\n Enter the Product ID [of length 10]:\n");
									pID = sc.nextLine();
									if (pID.length() <= 10) {
										break;
									}
								}
								Product.setProduct_id(pID);
								System.out.println("\n Product ID Modified");
								break;
							case 2:
								String product = "";
								while (true) {
									System.out.println("\n Enter the Product [of length 20]:\n");
									product = sc.nextLine();
									if (product.length() <= 20) {
										break;
									}
								}
								Product.setProduct(product);
								System.out.println("\n Product Modified");
								break;
							case 3:
								String model = "";
								while (true) {
									System.out.println("\n Enter the Model :\n");
									model = sc.nextLine();
									if (model.length() <= 10) {
										break;
									}
								}
								Product.setModel(model);
								System.out.println("\n Product Modified");
								break;
							case 4:
								String manufacturer = "";
								while (true) {
									System.out.println("\n Enter the Manuacturer :\n");
									manufacturer = sc.nextLine();
									if (manufacturer.length() <= 20) {
										break;
									}
								}
								Product.setManufacturer(manufacturer);
								System.out.println("\n Product Modified");
								break;
							case 5:
								String type_code = "";
								while (true) {
									System.out.println("\n Enter the Type Code :\n");
									type_code = sc.nextLine();
									if (type_code.length() <= 3) {
										break;
									}
								}
								Product.setType_code(type_code);
								System.out.println("\n Product Modified");
								break;
							case 6:
								String loc_code = "";
								while (true) {
									System.out.println("\n Enter the Type Code :\n");
									loc_code = sc.nextLine();
									if (loc_code.length() <= 3) {
										break;
									}
								}
								Product.setLoc_code(loc_code);
								System.out.println("\n Product Modified");
								break;
							case 7:
								System.out.println("\n Enter the MSRP :\n");
								Product.setMsrp(sc.nextFloat());
								System.out.println("\n Product Modified");
								break;
							case 8:
								System.out.println("Unit cost will be calculated based on MSRP and discount rate.");
								break;
							case 9:
								float discount_rate = 0;
								while (true) {
									System.out.println("\n Enter the Discount Rate between 0 and 100:\n");
									discount_rate = sc.nextFloat();
									if (discount_rate >= 0 && discount_rate < 100) {
										break;
									}
								}
								Product.setDisc_rate(discount_rate);
								System.out.println("\n Product Modified");
								break;
							case 10:
								int stock_quantity = 0;
								while (true) {
									System.out.println("\n Enter the Stock Quantity :\n");
									stock_quantity = sc.nextInt();
									if (stock_quantity >= 0) {
										break;
									}
								}
								Product.setQty(stock_quantity);
								System.out.println("\n Product Modified");
								break;
							}
						}
					}
				});
				break;
			case 4:
				exitmenu_4 = true;
				break;
			
			}

		}
	}
}
