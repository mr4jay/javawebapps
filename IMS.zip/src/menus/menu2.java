//menu 2 :Search products
package menus;
import java.util.* ;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;
import java.util.Scanner;
import models.Menu;
import models.Product;
import helpers.helper;

public class menu2 extends Menu {//menu 2 class
	public menu2() {
		super();
	}

	public void menu2_search(ArrayList<Product> InputData, ResourceBundle message) {
		//method to search products based on parameters like product ID,product,manufacturer etc.
		//precondition:product ID is unique in the inventory system
		Scanner sc = new Scanner(System.in);
		String[] subMenu = { "Menu2submenu1", "Menu2submenu2", "Menu2submenu3","Menu2submenu4","Menu2submenu5","Menu2submenu6","Menu2submenu7","Menu2submenu8", "Main_Menu","help" };
		Boolean exitmenu_2 = false;

		while (exitmenu_2 != true) {
			super.printSubMenu(subMenu, message);
			//printing sub menu to specify the search parameter
			int menu2opt=0;
			try {//exception try block
				menu2opt = sc.nextInt();
			} catch (Exception e) {
				sc.nextLine();//to handle invalid input values
			}
			int[] count = { 0 };
			switch (menu2opt) {//sub menu logic

			case 1:
				//Searching using Product ID
				System.out.println("\n Enter the product ID :\n");
				//prompt to enter product ID to search
				String Searchval = sc.next();
				//reading the entered product id
				System.out.println("\n Searching for product with the product ID: " + Searchval);
				Collections.sort(InputData, helper.compareById);
				System.out.println(helper.PrintHeader("default", " "));
				//sorting the input data by product id
				InputData.forEach(Product -> {
					//searching every product object for comparing its product id with the search value
					if (Searchval.equals(Product.getProduct_id())) {
						count[0]++;
						//incrementing the counter variable to calculate the total number of products returned
						Product.PrintProduct("default");
						//printing all the records found
					}
				});
				System.out.println("\n Total number of products found : " + count[0]);
				//printing the count of records returned
				count[0] = 0;
				//resetting the counter variable
				break;
			case 2:
				//Searching using Manufacturer name
				System.out.println("\n Enter the Manufacturer name : \n");
				//prompt to enter Manufacturer to search
				String Searchval_man = sc.next();
				//reading the entered Manufacturer name
				Collections.sort(InputData, helper.compareByManufacturer.thenComparing(helper.compareByProduct).thenComparing(helper.compareByModel).thenComparing(helper.compareById));
				//sorting the input data by Manufacturer,product,model and product id in case of multiple records under the same manufacturer
				System.out.println("\n Searching for products by the Manufacturer : " + Searchval_man);
				System.out.println(helper.PrintHeader("default", " "));
				InputData.forEach(Product -> {
					//searching every product object for comparing its Manufacturer with the search value

					if (Searchval_man.equals(Product.getManufacturer())) {
						count[0]++;
						//incrementing the counter variable to calculate the total number of products returned
						
						Product.PrintProduct("default");
						//printing all the records found

					}

				});
				System.out.println("\n Total number of products found : " + count[0]);
				//printing the count of records returned
				count[0] = 0;
				//resetting the counter variable
				break;
			
			case 3:
				//Searching using Product name
				System.out.println("\n Enter the Product name : \n");
				//prompt to enter Product to search
				String Searchval_pro = sc.next();
				//reading the entered Product name
				Collections.sort(InputData, helper.compareByProduct.thenComparing(helper.compareByModel).thenComparing(helper.compareByManufacturer).thenComparing(helper.compareById));
				//sorting the input data by Product,model,Manufacturer and product id in case of multiple records under the same product id
				System.out.println("\n Searching for products : " + Searchval_pro);
				System.out.println(helper.PrintHeader("default", " "));
				InputData.forEach(Product -> {
					//searching every product object for comparing its product name with the search value

					if (Searchval_pro.equals(Product.getProduct())) {
						count[0]++;
						//incrementing the counter variable to calculate the total number of products returned
						Product.PrintProduct("default");
						//printing all the records found

					}

				});
				System.out.println("\n Total number of products found : " + count[0]);
				//printing the count of records returned
				count[0] = 0;
				//resetting the counter variable
				break;

			case 4:
				//Searching using Model 
				System.out.println("\n Enter the Model name : \n");
				//prompt to enter Model to search
				String Searchval_mod = sc.next();
				//reading the entered Model name
				Collections.sort(InputData, helper.compareByModel.thenComparing(helper.compareByManufacturer).thenComparing(helper.compareByProduct).thenComparing(helper.compareById));
				//sorting the input data by Model,manufacturer,product and product id in case of multiple products under same model
				System.out.println("\n Searching products of the Model: " + Searchval_mod);
				System.out.println(helper.PrintHeader("default", " "));
				InputData.forEach(Product -> {
					//searching every product object for comparing its Model with the search value

					if (Searchval_mod.equals(Product.getModel())) {
						count[0]++;
						//incrementing the counter variable to calculate the total number of products returned
						Product.PrintProduct("default");
						//printing all the records found

					}

				});
				System.out.println("\n Total number of products found : " + count[0]);
				//printing the count of records returned
				count[0] = 0;
				//resetting the counter variable
				break;

			case 5:
				//Searching using Type code
				System.out.println("\n Enter the Type code : \n");
				//prompt to enter Type code to search
				String Searchval_typ = sc.next();
				//reading the entered Type code 
				Collections.sort(InputData, helper.compareByType.thenComparing(helper.compareByProduct).thenComparing(helper.compareByManufacturer).thenComparing(helper.compareById));
				//sorting the input data by Type code,product,manufacturer and product id in case of multiple records with same type code are returned
				System.out.println("\n Searching products of Type code: " + Searchval_typ);
				System.out.println(helper.PrintHeader("default", " "));
				InputData.forEach(Product -> {
					//searching every product object for comparing its Type code with the search value

					if (Searchval_typ.equals(Product.getType_code())) {
						count[0]++;
						//incrementing the counter variable to calculate the total number of products returned
						Product.PrintProduct("default");
						//printing all the records found

					}

				});
				System.out.println("\n Total number of products found : " + count[0]);
				//printing the count of records returned
				count[0] = 0;
				//resetting the counter variable
				break;
				
			case 6:
				//Searching using Location code
				System.out.println("\n Enter the Location code : \n");
				//prompt to enter Location code to search
				String Searchval_loc = sc.next();
				//reading the entered Location code 
				Collections.sort(InputData, helper.compareByLocation.thenComparing(helper.compareByProduct).thenComparing(helper.compareByManufacturer).thenComparing(helper.compareById));
				//sorting the input data by Location,product,manufacturer and product id in case of multiple records with same Location code are returned 
				System.out.println("\n Searching products in Location: " + Searchval_loc);
				System.out.println(helper.PrintHeader("default", " "));
				InputData.forEach(Product -> {
					//searching every product object for comparing its Location code with the search value

					if (Searchval_loc.equals(Product.getLoc_code())) {
						count[0]++;
						//incrementing the counter varaible to calculate the total number of products returned
						Product.PrintProduct("default");
						//printing all the records found

					}

				});
				System.out.println("\n Total number of products found : " + count[0]);
				//printing the count of records returned
				count[0] = 0;
				//resetting the counter variable
				break;

			case 7:
				//Searching using Discount rate
				System.out.println("\n Enter the discount rate : \n");
				//prompt to enter Discount rate to search
				String Searchval_dis = sc.next();
				//reading the entered Discount rate
				Collections.sort(InputData, helper.compareByDiscount.thenComparing(helper.compareByProduct).thenComparing(helper.compareById));
				//sorting the input data by Discount,product and product ID in case of multiple records with same discount rate
				System.out.println("\n Searching products for discount rate: " + Searchval_dis);
				System.out.println(helper.PrintHeader("default", " "));
				InputData.forEach(Product -> {
					//searching every product object for comparing its discount rate with the search value
				
					if (Searchval_dis.equals(String.valueOf(Product.getDisc_rate()))) {
						count[0]++;
						//incrementing the counter variable to calculate the total number of products returned
						Product.PrintProduct("default");
						//printing all the records found

					}

				});
				System.out.println("\n Total number of products found : " + count[0]);
				//printing the count of records returned
				count[0] = 0;
				//resetting the counter variable
				break;
			case 8:
				//returning to main menu
				exitmenu_2 = true;
				break;
			}
		}
	}
}