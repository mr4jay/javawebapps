package menus;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.ResourceBundle;
import java.util.Scanner;

import helpers.helper;
import models.Menu;
import models.Product;

public class menu1 extends Menu {
	public menu1() {
		super();
	}

	String[] subMenu = { "Menu1", "load_recent", "readDefault_dir", "loadfile_path", "Main_Menu" };

	// Main Function where Menu 1 starts
	public ArrayList<Product> readInputData(ArrayList<Product> InputData, ResourceBundle messages) throws Exception {
		Boolean header = true;
		Boolean exit = false;
		Boolean combine = false;
		Scanner sc = new Scanner(System.in);
		// Checking whether data exists already or not
		if (InputData.size() != 0) {
			System.out.println(messages.getString("combine_overwrite"));
			String option_combine = sc.next();
			// Looping to get exact input from user
			while (!option_combine.equalsIgnoreCase("Y") && !option_combine.equalsIgnoreCase("N")) {
				System.out.println(messages.getString("combine_overwrite"));
				option_combine = sc.next();
			}
			if (option_combine.equalsIgnoreCase("N"))
				combine = true;
		}
		while (exit == false) {
			super.printSubMenu(subMenu, messages);
			int option = 0;
			// Try Catch - To handle Inputmismatch Exception
			try {
				option = sc.nextInt();
			} catch (Exception e) {
				sc.nextLine();
			}
			String def_Path = "";
			switch (option) {
			default:
				System.out.println(messages.getString("select_below"));
				break;
			case 1: // Load Recent File
				def_Path = helper.getDef_Directory();
				try {
					InputData = readfromFile(InputData, def_Path + GetLastestFileName(def_Path), false, messages,
							combine);
				} catch (Exception e) {
					System.out.println("No Recent file found in the default directory");
				}
				return InputData;
			case 2: // Load File from Default Directory
				def_Path = helper.getDef_Directory();
				File dir = new File(def_Path);
				ArrayList<String> csv_files = getcsvFiles(dir);
				Collections.sort(csv_files);
				if (csv_files.size() != 0) {
					String FileName = getFileName(csv_files, messages);
					header = helper.whetherHeader(messages); // Function invoked
																// to get input
																// from user for
																// header
					InputData = readfromFile(InputData, def_Path + FileName, header, messages, combine);
					exit = true;
				} else
					System.out.println(messages.getString("no_csv"));
				break;
			case 3: // Load File from given Path
				System.out.println("Enter the file Location");
				sc.nextLine();
				String location = sc.nextLine();
				System.out.println(location);
				if (location.charAt(location.length() - 1) != '\\')
					location += "\\"; // IF the user enters location without \ at the end , \ is added
				File specified_dir = new File(location);
				if (specified_dir.isDirectory()) {
					ArrayList<String> csv_files1 = getcsvFiles(specified_dir);
					Collections.sort(csv_files1);
					if (csv_files1.size() != 0) {
						String FileName = getFileName(csv_files1, messages);
						header = helper.whetherHeader(messages);
						InputData = readfromFile(InputData, location + FileName, header, messages, combine);
						exit = true;
					} else
						System.out.println(messages.getString("no_csv"));
				} else
					System.out.println(messages.getString("directory_not_found"));
				break;
			case 4:
				exit = true;
				break;
			}

		}
		return InputData;
	}

	public static ArrayList<Product> readfromFile(ArrayList<Product> InputData, String Path, Boolean header,
			ResourceBundle messages, Boolean combine) throws Exception {
		if (!combine) // If overwrite, creating new arraylist
			InputData = new ArrayList<Product>();
		try {
			FileReader fis = new FileReader(new File(Path));
			BufferedReader br = new BufferedReader(fis);
			String str;
			int s_count = 0; // To count the number of records read
								// successfully
			if (header == true)
				br.readLine();
			while ((str = br.readLine()) != null) {
				String[] data = str.split(",");
				Product newProduct = new Product(data[0], data[1], data[2], data[3], data[4], data[5],
						Float.parseFloat(data[6]), Float.parseFloat(data[7]), Float.parseFloat(data[8]),
						Integer.parseInt(data[9]));
				InputData.add(newProduct);
				s_count++;
			}
			System.out.println(s_count + " " + messages.getString("readSuccess"));
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		return InputData;
	}

	public String getFileName(ArrayList<String> fileList, ResourceBundle messages) {
		Scanner sc = new Scanner(System.in);
		Boolean endofList = fileList.size() <= 5; // to check whether we are listing the last few in the file list
		int end = endofList ? fileList.size() : 5;
		for (int i = 0; i < end; i++) {
			System.out.println((i + 1) + ". " + fileList.get(i));
		}
		if (endofList == false) {
			System.out.println("6." + messages.getString("Load_More"));
			end = 6; // Condition to consider 6 as valid input
		}
		int option = 0;
		// Try Catch - To handle Inputmismatch Exception
		while (option <= 0 || option > end) { // Loop to get correct entry from
												// the user
			System.out.println("Select a file" + (endofList ? " " : " or Select Load More"));
			try {
				option = sc.nextInt();
			} catch (Exception e) {
				sc.next();
			}
		}
		if (option > 0 && option < end)
			return fileList.get((option - 1));
		else if (option != 6)
			return fileList.get((option - 1));
		else {
			for (int i = 0; i < 5; i++) {

				fileList.remove(0);
			}
			return getFileName(fileList, messages);
		}
		// return fileList.get(0);
	}

	public ArrayList<String> getcsvFiles(File dir) {
		File[] list_files = dir.listFiles();
		ArrayList<String> csv_files = new ArrayList<String>();
		for (File x : list_files) // Looping all the files in the folder
			if (x.getName().contains(".csv")) // Adds only csv files to the list
				csv_files.add(x.getName());
		return csv_files;

	}

	public String GetLastestFileName(String Path) {
		// String FileName = "";
		File dir = new File(Path);
		File[] list_files = dir.listFiles();
		ArrayList<String> csv_files = new ArrayList<String>();
		for (File x : list_files) // Looping all the files in the folder
			// Adds only csv files and files in IMS_Timestamp format to the list
			if (x.getName().contains(".csv") && x.getName().contains("IMS_"))
				csv_files.add(x.getName());
		// Sorting the files to get the latest file (timestamp in the file name is considered)
		Collections.sort(csv_files, new Comparator<String>() {
			@Override
			public int compare(String f1, String f2) {
				return (int) (Long.parseLong(f2.replaceAll("\\D", "")) - Long.parseLong(f1.replaceAll("\\D", "")));
			}
		});
		return csv_files.get(0);
	}

}