package helpers;

import java.awt.Desktop;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

import models.Product;

public class helper {

	// Sorting using comparator
	// Sort by ProductID
	public static Comparator<Product> compareById = (Product p1, Product p2) -> p1.getProduct_id()
			.compareTo(p2.getProduct_id());

	// Sort by Manufacturer
	public static Comparator<Product> compareByManufacturer = (Product p1, Product p2) -> p1.getManufacturer()
			.toLowerCase().compareTo(p2.getManufacturer().toLowerCase());
	// Sort by Product
	public static Comparator<Product> compareByProduct = (Product p1, Product p2) -> p1.getProduct()
			.toLowerCase().compareTo(p2.getProduct().toLowerCase());

	// Sort by Model
	public static Comparator<Product> compareByModel = (Product p1, Product p2) -> p1.getModel()
			.compareTo(p2.getModel());

	// Sort by Type
	public static Comparator<Product> compareByType = (Product p1, Product p2) -> p1.getType_code()
			.compareTo(p2.getType_code());

	// Sort by Location
	public static Comparator<Product> compareByLocation = (Product p1, Product p2) -> p1.getLoc_code()
			.compareTo(p2.getLoc_code());

	// Sort by Discount
	public static Comparator<Product> compareByDiscount = (Product p1, Product p2) -> Float.compare(p1.getDisc_rate(),
			p2.getDisc_rate());

	// Sort by Discount
	public static Comparator<Product> compareByQuantity = (Product p1, Product p2) -> Integer.compare(p1.getQty(),
			p2.getQty());

	public static void writetoFile(ArrayList<Product> InventoryData, String Order) {
		String Path = getDef_Directory();
		String pattern = "yyyyMMddHHmm";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		try {
			FileWriter fw = new FileWriter(new File(Path + "IMS_" + date + ".csv"));
			fw.write(PrintHeader("default", ","));
			fw.write('\n');
			for (int i = 0; i < InventoryData.size(); i++) {
				fw.write(InventoryData.get(i).getCompString(Order));
				fw.write('\n');
			}
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println(messages);

	}

	public static String PrintHeader(String order, String separator) {
		if (order.equals("default"))
			order = "1,2,3,4,5,6,7,8,9,10";
		String[] keys = order.split(",");
		String compositeKey = "";
		for (int i = 0; i < keys.length; i++) {

			switch (Integer.parseInt(keys[i])) {
			case 1:
				compositeKey += "Product Id";
				break;
			case 2:
				compositeKey += "Product";
				break;
			case 3:
				compositeKey += "Model";
				break;
			case 4:
				compositeKey += "Manufacturer";
				break;
			case 5:
				compositeKey += "Type Code";
				break;
			case 6:
				compositeKey += "Location Code";
				break;
			case 7:
				compositeKey += "MSRP";
				break;
			case 8:
				compositeKey += "Unit Cost";
				break;
			case 9:
				compositeKey += "Discount Rate";
				break;
			case 10:
				compositeKey += "Qty";
				break;

			}
			compositeKey += separator;
		}
		return compositeKey;

	}


	// Used in Menu 1(3) to ask whether the file selected has header or not
	public static Boolean whetherHeader(ResourceBundle messages) {
		System.out.println(messages.getString("whetherHeader"));
		Scanner sc = new Scanner(System.in);
		Boolean header = true;
		int i = 0;
		while (i == 0) {
			try {
				header = sc.nextBoolean();
				i = 1;
			} catch (Exception e) {
				System.out.println("Enter true or false");
				sc.next();
			}
		}

		return header;
	}

	public static String getDef_Directory() {
		String path = "";
		Scanner sc = new Scanner(System.in);
		String prop_Path = System.getProperty("user.dir") + "\\src\\com\\ims\\user.properties";
		try {
			InputStream input = new FileInputStream(prop_Path);
			Properties prop = new Properties();
			// load a properties file
			prop.load(input);
			// get the property value and print it out
			path = prop.getProperty("Def_Directory");
			File dir = new File(path);
			if (path.equals("") || !dir.exists()) {
				OutputStream output = new FileOutputStream(prop_Path);
				int i = 0;
				while (i == 0) {
					System.out.println("Enter the location to set as Defaulr Directory");
					path = sc.nextLine();
					if (path.charAt(path.length() - 1) != '\\')
						path += "\\";
					dir = new File(path);
					if (dir.isDirectory()) {
						prop.setProperty("Def_Directory", path);
						prop.store(output, "");
						return path;
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return path;

	}
}
