import java.util.*;

public class OrderedSubstrings {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        for(int i=0;i<n;i++){

            String str = scanner.next();
            System.out.println(SubString(str,str.length()));
        }

    }

    public static int SubString(String str, int n)
    {
        TreeSet<String> strings = new TreeSet<>();

        for (int i = 0; i < n; i++)
            for (int j = i+1; j <= n; j++)
                strings.add(str.substring(i, j));

         //Collections.sort(strings);

         int count = 0;
         for(String s:strings){
             count = count+1;
             if(s.equals(str)){
                 return count;
             }

         }

         return 0;
    }

}
/*

2
eren
acb

*/
