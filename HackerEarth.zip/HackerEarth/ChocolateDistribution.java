import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class ChocolateDistribution {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter wr = new PrintWriter(System.out);
        int T = Integer.parseInt(br.readLine().trim());
        for(int t_i=0; t_i<T; t_i++)
        {
            String[] temp = br.readLine().split(" ");
            int N = Integer.parseInt(temp[0]);
            int M = Integer.parseInt(temp[1]);
            String[] arr_chocolates = br.readLine().split(" ");
            int[] chocolates = new int[N];
            for(int i_chocolates=0; i_chocolates<arr_chocolates.length; i_chocolates++)
            {
                chocolates[i_chocolates] = Integer.parseInt(arr_chocolates[i_chocolates]);
            }

            int out_ = solution(chocolates, M, N);
            System.out.println(out_);
        }

        wr.close();
        br.close();
    }
    static int solution(int[] chocolates, int M, int N){
        // Find the maximum number of chocolates that can be selected.

        int sum = 0;

        for(int c : chocolates){
            sum = sum+c;
        }
            //System.out.println(sum);
        return (sum/N);
    }

}
/*
3
5 3
1 2 3 4 5
5 4
1 2 3 4 5
5 8
1 2 3 4 5
*/
