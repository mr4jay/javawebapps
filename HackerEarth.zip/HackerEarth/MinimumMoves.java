import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class MinimumMoves {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter wr = new PrintWriter(System.out);
        int T = Integer.parseInt(br.readLine().trim());
        for(int t_i=0; t_i<T; t_i++)
        {
            String[] NM = br.readLine().split(" ");
            int N = Integer.parseInt(NM[0]);
            int M = Integer.parseInt(NM[1]);
            int[][] Matrix = new int[N][2*M];
            for(int i_Matrix=0; i_Matrix<N; i_Matrix++)
            {
                String[] arr_Matrix = br.readLine().split(" ");
                for(int j_Matrix=0; j_Matrix<arr_Matrix.length; j_Matrix++)
                {
                    Matrix[i_Matrix][j_Matrix] = Integer.parseInt(arr_Matrix[j_Matrix]);
                }
            }

            int out_ = findMinimum(Matrix);
            System.out.println(out_);
        }

        wr.close();
        br.close();
    }
    static int findMinimum(int[][] Matrix){
        // Write your code here

        return 0;

    }

}
