package com.cg.entities;

import java.util.Date;

import javax.persistence.GeneratedValue;

public class Recharge {
	@GeneratedValue
private int rechargeId;
private String rechargeName;
private long phoneNumber;
private String plans;
private String discription;
private double amount;
private Date date;
public Recharge() {
	super();
 
}
public Recharge(int rechargeId, String rechargeName, long phoneNumber, String plans, String discription, double amount,
		Date date) {
	super();
	this.rechargeId = rechargeId;
	this.rechargeName = rechargeName;
	this.phoneNumber = phoneNumber;
	this.plans = plans;
	this.discription = discription;
	this.amount = amount;
	this.date = date;
}
public int getRechargeId() {
	return rechargeId;
}
public void setRechargeId(int rechargeId) {
	this.rechargeId = rechargeId;
}
public String getRechargeName() {
	return rechargeName;
}
public void setRechargeName(String rechargeName) {
	this.rechargeName = rechargeName;
}
public long getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(long phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getPlans() {
	return plans;
}
public void setPlans(String plans) {
	this.plans = plans;
}
public String getDiscription() {
	return discription;
}
public void setDiscription(String discription) {
	this.discription = discription;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}

}

