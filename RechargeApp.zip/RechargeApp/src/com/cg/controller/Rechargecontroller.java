package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


 
@Controller
public class Rechargecontroller {
	@RequestMapping("/index")
	public String getHomePage(Model model)
	{
		 
		return "index";
		
	}
	@RequestMapping("/recharge")
	public String save( ) {
 		return "recharge";
		
	}
}
