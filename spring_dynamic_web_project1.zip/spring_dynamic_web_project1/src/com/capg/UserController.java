package com.capg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("User")
public class UserController {
	
	@RequestMapping("showRegister")
	public String showRegister(Model model) {
		
		User user = new User();
		
		model.addAttribute("user",user);
		
		return "register";
	}
	
	
	@RequestMapping("checkRegister")
	public String checkRegister(User user, Model model) {
		
		model.addAttribute("user",user);
		
		return "registerSuccess";
	}


}
