package com.capg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	@Autowired
	Login login;
	
	/*public ModelAndView showpage() {
		
		
		return new ModelAndView("showpage");
	}*/
	@RequestMapping("/showpage")
	public String method (Model model) {
		
		String userName  = "Manoj";
		model.addAttribute("userName",userName);
		
		return "showpage";
	}
	
	
	public String method (@RequestParam("uName") String userName, @RequestParam("pass")String password,Model model) {
		
		model.addAttribute("userName",userName);
		model.addAttribute("password",password);
		
		return "mylogin";
	}
	
	
	@RequestMapping("/model")
	public String Mymethod (Model model) {
		
		model.addAttribute("login", login);
		
		return "login";
	}
	
	@RequestMapping("/mylogin")
	public String checkLogin(Login login) {
		
		if(login.getUserName().equals("admin")) {
			return "success";
				
		}
		return "mylogin";
		
	}

}
