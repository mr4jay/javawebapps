package com.cap.practice.BDDpractice;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features={"features"},plugin= {"pretty"},tags= {"@employeevalidate1"})
public class TestRunner
{

}
