package com.employee.bean;

public class CoursePage
{

}
