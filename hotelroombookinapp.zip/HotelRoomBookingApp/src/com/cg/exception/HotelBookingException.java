/**
 * 
 */
package com.cg.exception;


public class HotelBookingException extends Exception{
	public HotelBookingException(String msg) {
		super(msg);
	}

}
