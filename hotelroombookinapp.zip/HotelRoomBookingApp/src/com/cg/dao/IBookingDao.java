/**
 * 
 */
package com.cg.dao;

import java.util.List;

import com.cg.bean.BookingDetails;
import com.cg.bean.HotelDetails;


public interface IBookingDao {

	List<HotelDetails> getAllHotels();

	void addBooking(BookingDetails tr);

	HotelDetails getHnameBYId(Integer hotelid);

}
