package com.cg.dao;

import java.util.List;

import org.springframework.ui.Model;

import com.cg.entities.Employee;

public interface IEmployeeRepository {

public abstract Employee save(Employee employee);
	
	public abstract List<Employee> loadAll();
	
/*    public String salary(Employee employee,Model model);
*/
}
