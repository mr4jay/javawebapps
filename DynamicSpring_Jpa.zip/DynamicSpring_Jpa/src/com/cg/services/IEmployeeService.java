package com.cg.services;

import java.util.List;

import org.springframework.ui.Model;

import com.cg.entities.Employee;

public interface IEmployeeService {

	public abstract Employee save(Employee employee);
	
	public abstract List<Employee> loadAll();
	
/*    public String salary(Employee employee,Model model);
*/
}
