package com.cg.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.cg.dao.IEmployeeRepository;
import com.cg.entities.Employee;
@Service
@Transactional
public class EmployeeServiceImpl implements  IEmployeeService{
	@Autowired
	IEmployeeRepository employeeRepository;
	@Override
	public Employee save(Employee employee) {
		
 		return employeeRepository.save(employee);
	}

	@Override
	public List<Employee> loadAll() {
 		return employeeRepository.loadAll();
	}

	/*@Override
	public String salary(Employee employee, Model model) {
		// TODO Auto-generated method stub
		return null;
	}
*/
}
