package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;


@WebServlet("/ShowBalanceAccounts")
public class ShowBalanceAccounts extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	private static ICustomerService service=new CustomerServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		
		Integer custId=(Integer)session.getAttribute("customerid");
		List<Account> accounts=service.getAccounts(custId);
		
		/*
		
		double initialBalance=0;
		Long accountId=Long.parseLong(request.getParameter("account"));
		List<Transaction> transactions=service.getAccountTranscations(accountId);
		for(Account account:accounts) {
			if(account.getAccountNo() == custId) {
				initialBalance = account.getOpeningBalance();
			}
		
		double balance = service.calculateBalance(transactions,initialBalance);
		
		
		*/
		
		
		
		//double balance = 1000;
		
		PrintWriter out=response.getWriter();
		out.println("<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset='ISO-8859-1'>\r\n" + 
				"<title>Insert title here</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<form method='post' action='GetBalance'>\r\n" + 
				"	<table cellpadding='5px'>\r\n" + 
				"		<tr>\r\n" + 
				"			<th>choose account</th>\r\n" + 
				"			<td><select name='account'>\r\n");
				for(Account account:accounts){
					out.println("<option value='"+account.getAccountNo()+"'>"
							+ ""+account.getAccountNo()+" - "+account.getAccountType()+"</option>");
				} 
				out.println("			</select>\r\n" + 
				"			</td>\r\n" + 
				"		</tr>\r\n" + 
				"		<tr>\r\n" + 
				"			<td colspan='2' align='center'><input type='submit' name='show balance' value='show balance'></td>\r\n" + 
				"		</tr>\r\n" +
				"		<tr>\r\n" + 
				"			<th>balance</th>\r\n"  );
				
				double balance = (double) session.getAttribute("balance");
				
				out.println("			<td><input type='text' name='balance' value='"+balance+"' >" + 
						"				</td> " + 
						"				</tr>" + 
						"				</table>" + 
						"				</form>" + 
						"				</body>" + 
						"				</html>" + 
						"				");
				
	}

}
