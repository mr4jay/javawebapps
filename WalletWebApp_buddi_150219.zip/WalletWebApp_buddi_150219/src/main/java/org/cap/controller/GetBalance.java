package org.cap.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;


@WebServlet("/GetBalance")
public class GetBalance extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private static ICustomerService service=new CustomerServiceImpl();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double initialBalance=0;
		
		HttpSession session=request.getSession(false);
		Integer custId=(Integer)session.getAttribute("customerid");
		List<Account> accounts=service.getAccounts(custId);
		
		
		
		Long accountId=Long.parseLong(request.getParameter("account"));
		List<Transaction> transactions=service.getAccountTranscations(accountId);
		for(Account account:accounts) {
			if(account.getAccountNo() == accountId) {
				initialBalance = account.getOpeningBalance();
			}
			
		}
		
		
		double balance = service.calculateBalance(transactions,initialBalance);
		session.setAttribute("balance",balance);
		response.sendRedirect("ShowBalanceAccounts");
		
			
	}

}
