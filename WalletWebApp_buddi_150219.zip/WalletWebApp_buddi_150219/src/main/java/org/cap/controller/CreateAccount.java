package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;
import org.cap.util.AccountType;


@WebServlet("/CreateAccount")
public class CreateAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private ICustomerService customerService;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		customerService=new CustomerServiceImpl();
		AccountType accountType=AccountType.valueOf(request.getParameter("account_type"));
		String desc=request.getParameter("des");
		double openingBalance=Double.parseDouble(request.getParameter("balance"));
		HttpSession session=request.getSession(false);
		Integer custId=(Integer)session.getAttribute("customerid");
		Customer customer=customerService.findCustomer(custId);
		Account acc=new Account(openingBalance, accountType, desc, customer);
		if(customerService.createAccount(acc)) {
			
			request.getRequestDispatcher("pages/create_account.html").forward(request, response);
			
		}
	}

}
