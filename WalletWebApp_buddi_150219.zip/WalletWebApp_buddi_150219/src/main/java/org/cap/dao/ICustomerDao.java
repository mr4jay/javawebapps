package org.cap.dao;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface ICustomerDao {

	public boolean createCustomer(Customer customer);

	public Customer findCustomer(Integer custId);

	public boolean createAccount(Account acc);
	public Customer isValidLogin(Customer loginPojo);

	public List<Account> getAccounts(Integer custId);

	public Account findAccount(Long accountId);

	public boolean createTranscation(Transaction transaction);

	public List<Transaction> getAccountFromTranscations(Long accountId);

	public List<Transaction> getAccountToTranscations(Long accountId);
	
	public double calculateBalance(List<Transaction> transactions,double initialBalance);
	
	
}
