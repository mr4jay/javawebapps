package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.util.TransactionType;

public class CustomerDaoImpl implements ICustomerDao {

	@Override
	public boolean createCustomer(Customer customer) {
		
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			entityManager.persist(customer.getAddress());
			entityManager.persist(customer);
		
		transaction.commit();
		entityManager.close();
		
		if(customer.getCustomerId()>0)
			return true;
		return false;
	}

	
	private EntityManager getEntityManager() {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("jpademo");
		return emf.createEntityManager();
	}


	@Override
	public Customer findCustomer(Integer custId) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		Customer customer=entityManager.find(Customer.class, custId);
		transaction.commit();
		entityManager.close();
		return customer;
	}


	@Override
	public boolean createAccount(Account acc) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			entityManager.persist(acc);
		
		transaction.commit();
		entityManager.close();
		
		if(acc.getAccountNo()>0)
			return true;
		return false;
	}
	@Override
	public Customer isValidLogin(Customer loginPojo) {

		EntityManager manager=getEntityManager();

		EntityTransaction transaction= manager.getTransaction();

		transaction.begin();

		String sql="from Customer lgn where lgn.emailId=:uName and lgn.custPassword=:uPwd";

		Query query= manager.createQuery(sql);

		query.setParameter("uName", loginPojo.getEmailId());

		query.setParameter("uPwd", loginPojo.getCustPassword());

		List<Customer> logins= query.getResultList();

		transaction.commit();

		manager.close();

		if(logins.size()>0) 

			return logins.get(0);

		return null;

	}


	@Override
	public List<Account> getAccounts(Integer custId) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		String sql="select lgn.accounts from Customer lgn where lgn.customerId=:uName ";

		Query query= entityManager.createQuery(sql);

		query.setParameter("uName", custId);
		List<Account> accounts= query.getResultList();
		transaction.commit();
		entityManager.close();
		return accounts;
	}


	@Override
	public Account findAccount(Long accountId) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		Account account=entityManager.find(Account.class, accountId);
		transaction.commit();
		entityManager.close();
		return account;
	}


	@Override
	public boolean createTranscation(Transaction transaction) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction1= entityManager.getTransaction();
		transaction1.begin();
			entityManager.persist(transaction);
		
		transaction1.commit();
		entityManager.close();
		
		if(transaction.getTransactionId()!=0)
			return true;
		return false;
	}


	@Override
	public List<Transaction> getAccountFromTranscations(Long accountId) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		Account account=entityManager.find(Account.class, accountId);
		String sql="select lgn.transactions from Account lgn where lgn.accountNo=:accno";

		Query query= entityManager.createQuery(sql);

		query.setParameter("accno", accountId);

		List<Transaction> transactions= query.getResultList();
		String sql1="select lgn.toTransactions from Account lgn where lgn.accountNo=:accno";

		Query query1= entityManager.createQuery(sql1);

		query1.setParameter("accno", accountId);

		List<Transaction> totransactions= query1.getResultList();
		transactions.addAll(totransactions);
		transaction.commit();
		entityManager.close();
		return transactions;
	}


	@Override
	public List<Transaction> getAccountToTranscations(Long accountId) {
		return null;
	}


	@Override
	public double calculateBalance(List<Transaction> transactions,double initialBalance) {
		// TODO Auto-generated method stub
		double balance = 0;
		for(Transaction transaction:transactions) {
			
			if(transaction.getTransactionType().equals(TransactionType.DEBIT)) {
				
				 balance-=  transaction.getAmount();
			}
			
			else if(transaction.getTransactionType().equals(TransactionType.CREDIT)) {
				
				 balance+=  transaction.getAmount();
			}
			
				balance = initialBalance + balance;
		}
		
		return balance;
	}

}
