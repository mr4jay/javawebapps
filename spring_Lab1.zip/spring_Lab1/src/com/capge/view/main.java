package com.capge.view;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.capge.bean.EmployeeBean;

public class main {
	
	public static void main(String[]args) {
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("employee.xml");
		EmployeeBean bean = (EmployeeBean) applicationContext.getBean("EmployeeBean");
		
		System.out.println(bean.getBusinessUnit().toString());
		
	}
	

}
