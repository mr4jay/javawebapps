package com.capge.bean;

import java.util.List;

public class EmployeeBean {
	private int employeeId;
	private String employeeName;
	private double employeeSalary;
	private List<SBU> businessUnit;
	private int employeeAge;
	
	public EmployeeBean() {
		super();
	}


	public List<SBU> getBusinessUnit() {
		return businessUnit;
	}


	public void setBusinessUnit(List<SBU> businessUnit) {
		this.businessUnit = businessUnit;
	}


	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}


	public int getEmployeeAge() {
		return employeeAge;
	}

	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}
	
	
}
