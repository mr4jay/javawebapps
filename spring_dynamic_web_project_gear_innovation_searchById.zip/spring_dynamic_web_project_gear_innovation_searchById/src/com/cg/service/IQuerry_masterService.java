package com.cg.service;

import java.util.List;

import com.cg.entities.Querry_master;


public interface IQuerry_masterService {
	
	public abstract Querry_master save(Querry_master querry_master);
	public abstract List<Querry_master> loadAll();
	public abstract Querry_master getByquerryId(Integer querryId);

}
