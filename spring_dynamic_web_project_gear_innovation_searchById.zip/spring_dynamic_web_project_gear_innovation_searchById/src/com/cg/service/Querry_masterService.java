package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.IQuerry_masterRepository;
import com.cg.entities.Querry_master;




@Service
@Transactional
public class Querry_masterService implements IQuerry_masterService {
	
	@Autowired
	IQuerry_masterRepository querry_masterRepository ;
	
	
	
	@Override
	public Querry_master save(Querry_master querry_master) {
		// TODO Auto-generated method stub
		
		
		return querry_masterRepository.save(querry_master);
	}
	
	@Override
	public List<Querry_master> loadAll() {
		// TODO Auto-generated method stub
		
		
		return querry_masterRepository.loadAll();
	}

	@Override
	public Querry_master getByquerryId(Integer querryId) {
		// TODO Auto-generated method stub
		return querry_masterRepository.getByquerryId(querryId);
	}


}
