package com.cg.entities;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="querry_master")
public class Querry_master implements Serializable {
	
	@Id
	@Column(name="querry_id")
	private Integer querryId;
	private String technology;
	@Column(name="querry_raised")
	private String querryRaisedBy; 
	private String querry;
	private String solutions;
	@Column(name = "solution_given_by")
	private String solutionGivenBy;
	
	public Querry_master() {
		super();
	}

	public Integer getquerryId() {
		return querryId;
	}

	public void setquerryId(Integer querryId) {
		this.querryId = querryId;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQuerryRaisedBy() {
		return querryRaisedBy;
	}

	public void setQuerryRaisedBy(String querryRaisedBy) {
		this.querryRaisedBy = querryRaisedBy;
	}

	public String getQuerry() {
		return querry;
	}

	public void setQuerry(String querry) {
		this.querry = querry;
	}

	public String getSolutions() {
		return solutions;
	}

	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}

	public String getSolutionGivenBy() {
		return solutionGivenBy;
	}

	public void setSolutionGivenBy(String solutionGivenBy) {
		this.solutionGivenBy = solutionGivenBy;
	}

	@Override
	public String toString() {
		return "Querry_master [querryId=" + querryId + ", technology=" + technology + ", querryRaisedBy="
				+ querryRaisedBy + ", querry=" + querry + ", solutions=" + solutions + ", solutionGivenBy="
				+ solutionGivenBy + "]";
	}
	
	
		

}
