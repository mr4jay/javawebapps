package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Querry_master;




@Repository
public class Querry_masterRepository implements IQuerry_masterRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Querry_master save(Querry_master querry_master) {
		// TODO Auto-generated method stub
		
		
		Querry_master querry_masterUpdate = entityManager.find(Querry_master.class,querry_master.getquerryId());
		querry_masterUpdate.setSolutionGivenBy(querry_master.getSolutionGivenBy());
		querry_masterUpdate.setSolutions(querry_master.getSolutions());
		entityManager.persist(querry_masterUpdate);
		entityManager.flush();
		return querry_master;
	}

	@Override
	public List<Querry_master> loadAll() {
		// TODO Auto-generated method stub
		TypedQuery<Querry_master> query =  entityManager.createQuery("select s from Querry_master s" ,Querry_master.class);
		return query.getResultList();
	}

	@Override
	public Querry_master getByquerryId(Integer querryId) {
		// TODO Auto-generated method stub
		Querry_master querry_master = entityManager.find(Querry_master.class, querryId);
		if (querry_master != null) {
			return querry_master;
		}
		return null;
	}
	
	

}
