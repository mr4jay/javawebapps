package com.cg.dao;

import java.util.List;

import com.cg.entities.Querry_master;





public interface IQuerry_masterRepository {
	
	public abstract Querry_master save(Querry_master querry_master);
	public abstract List<Querry_master> loadAll();
	public abstract Querry_master getByquerryId(Integer querryId);

}
