package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Querry_master;

import com.cg.service.IQuerry_masterService;


@Controller
public class Querry_masterController {
	
	@Autowired
	IQuerry_masterService querry_masterService;
	
	@RequestMapping("/index")
	public String index(Model model, Querry_master querry_master) {
		
		
		return "index";
		
	}
	
	@RequestMapping("/givequerryid")
	public String givequerrtid() {
		
		
		return "givequerryid";
	}
	
	
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveSessionMgmt(@ModelAttribute("Querry_master") Querry_master querry_master, Model model) {
		System.out.println(querry_master);
		querry_master = querry_masterService.save(querry_master);
		//model.addAttribute("message","EmployeeId with Id"+querry_master.getName()+"added Successfully");
		return "success";
		
	}
	
	@RequestMapping("/answerQuerry")
	public String getHomePage(@RequestParam("querryId") String querryId ,Model model) {
		
		model.addAttribute("solutionGivenBy",new String[] {"System Associate","Asst Manager",
				"Dy Manager","Manager"});
		
		Querry_master querry_master = querry_masterService.getByquerryId(Integer.parseInt(querryId));
		
		if (querry_master!=null) {
			model.addAttribute("Querry_master",querry_master);
			return "answerQuerry";
				
		}
		
		return "failed";
		
	}
	
	@RequestMapping("/success")
	public String redirect(@RequestParam("name") String name, Model model) {
		
		
		
		return "success";
	}

}
