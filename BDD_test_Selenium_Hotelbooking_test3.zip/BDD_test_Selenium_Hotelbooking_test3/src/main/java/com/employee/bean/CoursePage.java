package com.employee.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CoursePage
{
	@FindBy(how=How.ID,id="graduation")
	WebElement graduation;
	
	@FindBy(how=How.ID,id="txtPercentage")
	WebElement percentage;
	
	@FindBy(how=How.ID,id="txtPassYear")
	WebElement passingYear;
	
	@FindBy(how=How.ID,id="txtProjectName")
	WebElement projectName;
	
	@FindBy(how=How.ID,id="cbTechnologies")
	List<WebElement> technologies;
	
	@FindBy(how=How.ID,id="txtOtherTechs")
	WebElement otherTechnologies;
	
	@FindBy(how=How.ID,id="btnRegister")
	WebElement button;
	
	public void setButtan() {
		// TODO Auto-generated method stub
		button.click();

	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public void setTechnologies(int i) {
		/*this.technologies.sendKeys(technologies);*/
		this.technologies.get(i).click();
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}
	
	
	
	
	

}
