package com.cap.practice.BDDpractice;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.employee.bean.CoursePage;
import com.employee.bean.EmployeePage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef 
{
	EmployeePage employeepage;
	CoursePage coursePage;
	WebDriver driver;
	String employee;
	@Before
	public void init()
	{
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver_1.exe");
		driver =new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		employeepage=new EmployeePage();
		coursePage = new CoursePage();
		PageFactory.initElements(driver,employeepage);
		PageFactory.initElements(driver ,coursePage );
	}
	
	@After
	public void finish() throws Exception
	{
		Thread.sleep(5000);
		driver.quit();
	}
	@Given("^employee page validation$")
	public void employee_page_validation() throws Throwable
	{
	    driver.get("file:///C:/Users/MKOTTEDA/Desktop/demo/BDD_test_Selenium_Hotelbooking_test3/webpages/Employee%20Details.html");
    }
	@When("^check titlefor employee page$")
	public void check_titlefor_employee_page() throws Throwable 
	{
	    employee=driver.getTitle();
	}

	@Then("^title should come employee details$")
	public void title_should_come_employee_details() throws Throwable 
	{
		String expected="Employee Details";
		assertEquals(expected, employee);
		
	}

	@When("^clicking on next without entering first name$")
	public void clicking_on_next_without_entering_first_name() throws Throwable 
	{
		employeepage.clickLink();
	}

	@Then("^get alert message 'Please fill the first name'$")
	public void get_alert_message_Please_fill_the_first_name() throws Throwable 
	{
	    String actual = driver.switchTo().alert().getText();
	    String expected="Please fill the First Name";
		assertEquals(expected, actual);
	}

	@When("^clicking on next without entering last name$")
	public void clicking_on_next_without_entering_last_name() throws Throwable 
	{
	   driver.switchTo().alert().dismiss();
	   employeepage.setFirstName("manoj");
	   employeepage.clickLink();
	   Thread.sleep(500);
	}

	@Then("^get alert message 'Please fill the last name'$")
	public void get_alert_message_Please_fill_the_last_name() throws Throwable 
	{
		String actual =driver.switchTo().alert().getText();
	    String expected="Please fill the Last Name";
		assertEquals(expected, actual);
	}

	@When("^clicking on next without entering email$")
	public void clicking_on_next_without_entering_email() throws Throwable
	{
		   driver.switchTo().alert().dismiss();
		   employeepage.setLastName("k");
		   employeepage.clickLink();
		   Thread.sleep(500);
	}

	@Then("^get alert message 'Please fill the email'$")
	public void get_alert_message_Please_fill_the_email() throws Throwable 
	{
		String actual =driver.switchTo().alert().getText();
	    String expected="Please fill the Email";
		assertEquals(expected, actual);
	}

	@When("^clicking on next without entering valid email$")
	public void clicking_on_next_without_entering_valid_email() throws Throwable 
	{
		   driver.switchTo().alert().dismiss();
		   employeepage.setEmail("mojo");
		   employeepage.clickLink();
		   Thread.sleep(500);   
	}

	@Then("^get alert message 'Please fill the valid email'$")
	public void get_alert_message_Please_fill_the_valid_email() throws Throwable 
	{
		String actual =driver.switchTo().alert().getText();
	    String expected="Please enter valid Email Id.";
		assertEquals(expected, actual);
	}

	@When("^clicking on next without entering contact$")
	public void clicking_on_next_without_entering_contact() throws Throwable 
	{
		   driver.switchTo().alert().dismiss();
		   employeepage.setEmail("manoj@gmail.com");
		   employeepage.clickLink();
		   Thread.sleep(500); 
	}

	@Then("^get alert message 'Please fill the contact no\\.'$")
	public void get_alert_message_Please_fill_the_contact_no() throws Throwable
	{
		String actual =driver.switchTo().alert().getText();
	    String expected="Please fill the Contact No.";
		assertEquals(expected, actual);
	}

	@When("^clicking on next without entering valid contact$")
	public void clicking_on_next_without_entering_valid_contact() throws Throwable
	{
		   driver.switchTo().alert().dismiss();
		   employeepage.setContact("96322");
		   employeepage.clickLink();
		   Thread.sleep(500);
	}

	@Then("^get alert message 'Please fill the valid contact'$")
	public void get_alert_message_Please_fill_the_valid_contact() throws Throwable 
	{
		String actual =driver.switchTo().alert().getText();
	    String expected="Please enter valid Contact no.";
		assertEquals(expected, actual);
	}

	@When("^clicking on next without entering address line one$")
	public void clicking_on_next_without_entering_address_line_one() throws Throwable {
		   driver.switchTo().alert().dismiss();
		   employeepage.setContact("9989048825");
		   employeepage.clickLink();
		   Thread.sleep(500);
	}

	@Then("^get alert message 'Please fill the address line one'$")
	public void get_alert_message_Please_fill_the_address_line_one() throws Throwable {
		String actual =driver.switchTo().alert().getText();
	    String expected="Please fill the address line 1";
		assertEquals(expected, actual);
		
	}

	@When("^clicking on next without address line two$")
	public void clicking_on_next_without_address_line_two() throws Throwable {
		driver.switchTo().alert().dismiss();
		   employeepage.setAddLineOne("Plot no:157, kamalanagar");
		   employeepage.clickLink();
		   Thread.sleep(500);
	
	}

	@Then("^get alert message 'Please fill the address line two'$")
	public void get_alert_message_Please_fill_the_address_line_two() throws Throwable {
		String actual =driver.switchTo().alert().getText();
	    String expected="Please fill the address line 2";
		assertEquals(expected, actual);
	}

	@When("^clicking on next without entering city$")
	public void clicking_on_next_without_entering_city() throws Throwable
	{
		String actual =driver.switchTo().alert().getText();
	    String expected="Please fill the address line 2";
		assertEquals(expected, actual);
	}

	@Then("^get alert message 'Please fill the city'$")
	public void get_alert_message_Please_fill_the_city() throws Throwable 
	{
		   driver.switchTo().alert().dismiss();
		   employeepage.setAddLineTwo("vanasthalipuram");
		   employeepage.clickLink();
		   Thread.sleep(500);
	}

	@When("^clicking on next without entering state$")
	public void clicking_on_next_without_entering_state() throws Throwable 
	{
		String actual =driver.switchTo().alert().getText();
	    String expected="Please select city";
		assertEquals(expected, actual);
	}

	@Then("^get alert message 'Please fill the state'$")
	public void get_alert_message_Please_fill_the_state() throws Throwable
	{
		   driver.switchTo().alert().dismiss();
		   employeepage.setCity("Hyderabad");
		   employeepage.clickLink();
		   Thread.sleep(500);
	}

	@When("^clicking on next with entering all personal details$")
	public void clicking_on_next_with_entering_all_personal_details() throws Throwable 
	{
		String actual =driver.switchTo().alert().getText();
	    String expected="Please select state";
		assertEquals(expected, actual);
	}

	@Then("^get alert message 'All the personal details are validated and accepted'$")
	public void get_alert_message_All_the_personal_details_are_validated_and_accepted() throws Throwable 
	{
		   driver.switchTo().alert().dismiss();
		   employeepage.setState("Telangana");
		   employeepage.clickLink();
		   Thread.sleep(500);
	}
	/*when{
		    String actual =driver.switchTo().alert().getText();
		    String expected="Personal details are validated and accepted successfully.";
			assertEquals(expected, actual);
		}*/
	
	
	
	
	@Given("^course page validation$")
	public void course_page_validation() throws Throwable {
		 driver.get("file:///C:/Users/MKOTTEDA/Desktop/demo/BDD_test_Selenium_Hotelbooking_test3/webpages/CoursesToOpt.html");
	   
	}
	@When("^check title for course page$")
	public void check_title_for_course_page() throws Throwable {
		employee=driver.getTitle();
	}

	@Then("^title should give courses to opt$")
	public void title_should_give_courses_to_opt() throws Throwable {
		
		String expected="Courses To Opt";
		assertEquals(expected, employee);
	     
	}

	@When("^clicking ov button without entering graduation$")
	public void clicking_ov_button_without_entering_graduation() throws Throwable {
		
		coursePage.setButtan();
	   
	}

	@Then("^get alert message 'Please select Graduation'$")
	public void get_alert_message_Please_select_Graduation() throws Throwable {
		 
		String actual = driver.switchTo().alert().getText();
		    String expected="Please Select Graduation";
			assertEquals(expected, actual);
	}

	@When("^clicking ov button without entering Percentage$")
	public void clicking_ov_button_without_entering_Percentage() throws Throwable {
		
		driver.switchTo().alert().dismiss();
		   coursePage.setGraduation("BE");
		   coursePage.setButtan();
		   Thread.sleep(500);
	   
	}

	@Then("^get alert message 'Please select Percentage'$")
	public void get_alert_message_Please_select_Percentage() throws Throwable {
		
		String actual = driver.switchTo().alert().getText();
	    String expected="Please fill Percentage detail";
		assertEquals(expected, actual);
	  
	}

	@When("^clicking ov button without entering Passing year$")
	public void clicking_ov_button_without_entering_Passing_year() throws Throwable {
		driver.switchTo().alert().dismiss();
		   coursePage.setPercentage("94");
		   coursePage.setButtan();
		   Thread.sleep(500);
	    
	}

	@Then("^get alert message 'Please select Passing year'$")
	public void get_alert_message_Please_select_Passing_year() throws Throwable {
		
		String actual = driver.switchTo().alert().getText();
	    String expected="Please fill Passing Year";
		assertEquals(expected, actual);
	   
	}

	@When("^clicking ov button without entering Project name$")
	public void clicking_ov_button_without_entering_Project_name() throws Throwable {
		driver.switchTo().alert().dismiss();
		   coursePage.setPassingYear("2019");
		   coursePage.setButtan();
		   Thread.sleep(500);
	 
	}

	@Then("^get alert message 'Please select Project name'$")
	public void get_alert_message_Please_select_Project_name() throws Throwable {
		
		String actual = driver.switchTo().alert().getText();
	    String expected="Please fill Project Name";
		assertEquals(expected, actual);
	 
	}

	@When("^clicking ov button without entering Technologies used$")
	public void clicking_ov_button_without_entering_Technologies_used() throws Throwable {
		driver.switchTo().alert().dismiss();
		   coursePage.setProjectName("Free-lance robot");
		   coursePage.setButtan();
		   Thread.sleep(500);
	  
	}

	@Then("^get alert message 'Please select Technologies used'$")
	public void get_alert_message_Please_select_Technologies_used() throws Throwable {
		
		String actual = driver.switchTo().alert().getText();
	    String expected="Please Select Technologies Used";
		assertEquals(expected, actual);
		
	    }

	@When("^clicking on button without entering other Technologies used$")
	public void clicking_on_button_without_entering_other_Technologies_used() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		  /* coursePage.setGraduation("Arduino");
		   coursePage.setButtan();*/
		coursePage.setTechnologies(0);
		coursePage.setTechnologies(3);
		coursePage.setButtan();
		   Thread.sleep(500);
	}
	
	@Then("^get alert message 'Please fill other Technologies Used'$")
	public void get_alert_message_Please_fill_other_Technologies_Used() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		String actual = driver.switchTo().alert().getText();
	    String expected="Please fill other Technologies Used";
		assertEquals(expected, actual);
	}
	
	@When("^clicking on button with entering other Technologies$")
	public void clicking_on_button_with_entering_other_Technologies() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().dismiss();
		   coursePage.setOtherTechnologies("Eagle");
		   coursePage.setButtan();
		   Thread.sleep(500);
	    
	}
	
	@Then("^get alert message 'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!'$")
	public void get_alert_message_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual = driver.switchTo().alert().getText();
	    String expected="Your Registration Has succesfully done Plz check you registerd email for account activation link !!!";
		assertEquals(expected, actual);
	}




}	
