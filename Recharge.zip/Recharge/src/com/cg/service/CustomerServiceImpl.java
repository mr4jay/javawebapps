package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.CustomerRepository;
import com.cg.entities.Customer;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerRepository customerRepository; 
	
	@Override
	public Customer save(Customer customer) {
		customer.setAmount(Double.parseDouble(customer.getPlan().substring(2,customer.getPlan().length()))+1000.00);
		return customerRepository.save(customer);
	}

	@Override
	public List<Customer> showTransactions() {
		return customerRepository.showTransactions();	
		}

	@Override
	public Customer getTransaction(int rechargeId) {
		return customerRepository.getTransaction(rechargeId);
	}

	
}
