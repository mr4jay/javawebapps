package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Customer;
import com.cg.service.CustomerService;



@Controller
public class EmployeeController {
	ArrayList<String> plans;
	
	@Autowired
	CustomerService customerService; 
	
	@RequestMapping("/index")
	public String getHomePage(Model model) {
		plans=new ArrayList<String>();
	plans.add("rc100");
	plans.add("rc200");
	plans.add("rc500");
		return "index";
	}
	
	@RequestMapping("/recharge")
	public String recharge(Model model ) {
		plans=new ArrayList<String>();
		plans.add("rc100");
		plans.add("rc200");
		plans.add("rc500");
		model.addAttribute("plans",plans );
		model.addAttribute("customer", new Customer());
		return "recharge";
	}
	
	@RequestMapping(value="/save")
	public String save(@ModelAttribute("customer")@Valid Customer customer,BindingResult result,Model model ) {
		if(result.hasErrors()) {
		model.addAttribute("plans",plans);
		return "recharge";
		}
		else {
		customer=customerService.save(customer);
		model.addAttribute("message","transcation id is "+customer.getRechargeId()+"\n transaction done successful");
		return "redirect:/index.html";
		}
	}
	
	@RequestMapping("/alltransactions")
	public String showTranscations(Model model) {
		model.addAttribute("customers",customerService.showTransactions());
		return "display";
	}
	
	@RequestMapping("/transactionbyid")
	public String transactionbyid(Model model) {
		return "gettransaction";
	}
	
	@RequestMapping("/getid")
	public String getId(Model model,@RequestParam("transactionid")String rechargeId) {
		model.addAttribute("customer",customerService.getTransaction(Integer.parseInt(rechargeId)));
		return "Showbyid";
	}
	
	@RequestMapping("/offers")
	public String offers(Model model) {
		
		model.addAttribute("plans",plans);
		return "offers";
	}
}
