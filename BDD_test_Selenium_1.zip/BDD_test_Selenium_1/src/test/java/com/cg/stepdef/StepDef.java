package com.cg.stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	WebDriver driver;
	By User_id;
	By User_pass;
	By button;
	
	
	
	@Given("^username and password$")
	public void username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver_1.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://login.wordpress.org/");
		User_id=By.id("user_login");//or use By.name,By.xpath etc...
		User_pass = By.xpath("//*[@id=\"user_pass\"]");//or use By.name,By.id,By.class etc...
		button = By.id("wp-submit");
	}

	@When("^valid username and password$")
	public void valid_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.findElement(User_id).sendKeys("manojkotteda");
	    driver.findElement(User_pass).sendKeys("dragenballz0");
	    driver.findElement(button).click();
	    
	}

	@Then("^show success page$")
	public void show_success_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Login done...");
	    
	}



}
