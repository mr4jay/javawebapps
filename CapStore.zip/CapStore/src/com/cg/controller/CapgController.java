package com.cg.controller;

import java.io.File;
import java.time.LocalDate;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cg.entities.Inventory;
import com.cg.entities.ReturnedItems;
import com.cg.entities.SoldItems;
import com.cg.service.ICapgService;

@Controller
public class CapgController {
	
	@Autowired
	ICapgService iQueryService;
	
	
	@RequestMapping("/business")
	public String business(Model model) {
		
		iQueryService.plp();
		return "business";
			
	}
	
	
	@RequestMapping("/businessAnalysis")
	public String businessByProducts(@RequestParam("requestType")String requestType,@RequestParam("productName")String productName,
			@RequestParam("merchantName")String merchantName,
			@RequestParam("fromDate")String fromDate,@RequestParam("toDate")String toDate, Model model) {
		
			double totalProfit=0,soldCount=0,totalQuantitySold=0 ;
		
		//Date conversion:
		String toDate1= toDate;
		String fromDate1= fromDate;
		String[] dob=toDate1.split("-");
		LocalDate toDateToPass=(LocalDate.of(Integer.parseInt(dob[0]),
				Integer.parseInt(dob[1]), Integer.parseInt(dob[2])));
		dob=fromDate1.split("-");
		LocalDate fromDateToPass=(LocalDate.of(Integer.parseInt(dob[0]),
				Integer.parseInt(dob[1]), Integer.parseInt(dob[2])));
		
		
		//Data Retrieval Logic
		
		if(requestType.equals("products")) {
			
			List<SoldItems> soldItems = iQueryService.getBusinessByProducts(productName,fromDateToPass,toDateToPass); 
			model.addAttribute("soldItemsList",soldItems); 
			
			for(SoldItems items:soldItems) {
				
				totalProfit += items.getInventory().getPrice();
				soldCount = soldCount+1;
				totalQuantitySold += items.getInventory().getQuantity();
				
			}
			
		} 
		
		if (requestType.equals("ProductType")) {
			
			List<SoldItems> soldItems = iQueryService.getBusinessByProductCatagory(productName,fromDateToPass,toDateToPass);
			
			model.addAttribute("soldItemsList",soldItems); 
			
			for(SoldItems items:soldItems) {
				
				totalProfit += items.getInventory().getPrice();
				soldCount = soldCount+1;
				totalQuantitySold += items.getInventory().getQuantity();
				
			}
			
			
		} 
		
		if (requestType.equals("MerchantProductType")) {
			
			List<SoldItems> soldItems = iQueryService.getBusinessByProductsAndMerchant(productName, merchantName,fromDateToPass,toDateToPass);
			
			model.addAttribute("soldItemsList",soldItems); 
			
			for(SoldItems items:soldItems) {
				
				totalProfit += items.getInventory().getPrice();
				soldCount = soldCount+1;
				totalQuantitySold += items.getInventory().getQuantity();
				
			}
			
		}
		
		model.addAttribute("totalProfit", totalProfit);
		model.addAttribute("soldCount", soldCount);
		model.addAttribute("totalQuantitySold", totalQuantitySold);
		
		
		return "businessAnalysis";
	}
	
	
	//------------------------------------------ash---------------------------------------------------//
	
	@RequestMapping("/customerReturnItems")
	public String customerReturnItems(Model model) {
		iQueryService.plp();
		model.addAttribute("solditems", iQueryService.loadSoldItems()); 
		return "customerReturnItems";
	}
	
	
	@RequestMapping("/returnedToAdmin")
	public String returnItem(@RequestParam("soldItemId") Integer soldItemId,Model model) {
		iQueryService.returnItems(soldItemId, LocalDate.now());
		model.addAttribute("returneditems", iQueryService.loadReturnedItems()) ;
		return "returnedToAdmin";
	}
	
	@RequestMapping("/view1")
	public String view1(@RequestParam("soldItemId") Integer soldItemId,Model model) {
		boolean b =  iQueryService.updateInventoryByAdmin(soldItemId, LocalDate.now());
		if (b==true) {
			iQueryService.refundMoney(soldItemId);
			return "view1";
		}
		return "view2";
	}
	
	
}
