package com.cg.controller;

import java.io.File;
import java.time.LocalDate;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cg.entities.Inventory;
import com.cg.entities.ReturnedItems;
import com.cg.entities.SoldItems;
import com.cg.service.ICapgService;

@Controller
public class CapgController {
	
	@Autowired
	ICapgService iQueryService;
	
	@RequestMapping("/index")
	public String index(Model model) {
		iQueryService.plp();
		iQueryService.getBusinessByProducts("qqede",LocalDate.of(2019, 01, 05),LocalDate.of(2019, 04, 05));
		iQueryService.getBusinessByProductCatagory("edeq", LocalDate.of(2019, 01, 05), LocalDate.of(2019, 04, 05));
		iQueryService.getBusinessByProductsAndMerchant("fgh", "eefewf", LocalDate.of(2019, 01, 05), LocalDate.of(2019, 04, 05));
		iQueryService.refundMoney(8);
		System.out.println("Hi hell");
		return "index";
	}
	
	
	
	
	//------------------------------------------ash---------------------------------------------------//
	
	@RequestMapping("/customerReturnItems")
	public String customerReturnItems(Model model) {
		iQueryService.plp();
		//iQueryService.updateInventory(soldItemId, LocalDate.now());
		model.addAttribute("solditems", iQueryService.loadSoldItems()); 
		return "customerReturnItems";
	}
	
	
	/*@RequestParam("soldDate") String soldDate ,*/
	@RequestMapping("/returnedToAdmin")
	public String returnItem(@RequestParam("soldItemId") Integer soldItemId,Model model) {
		//iQueryService.updateInventory(soldItemId, LocalDate.now());
		iQueryService.returnItems(soldItemId, LocalDate.now());
		model.addAttribute("returneditems", iQueryService.loadReturnedItems()) ;
		System.out.println(soldItemId);
		return "returnedToAdmin";
	}
	
	@RequestMapping("/view1")
	public String view1(@RequestParam("soldItemId") Integer soldItemId,Model model) {
		boolean b =  iQueryService.updateInventoryByAdmin(soldItemId, LocalDate.now());
		if (b==true) {
			return "view1";
		}
		return "view2";
	}
	
	
	
	/*
	
	
	@RequestMapping("/doUpload")
	public String fileupload(@RequestParam CommonsMultipartFile[] fileUpload) {
		 if (fileUpload != null && fileUpload.length > 0) {
	           for (CommonsMultipartFile aFile : fileUpload){  
	                System.out.println("Saving file: " + aFile.getOriginalFilename());
	                Inventory inventory=new Inventory();
	                inventory.setFileName(aFile.getOriginalFilename());
	 	           File convFile = new File(aFile.getOriginalFilename());
	 	           try {
					aFile.transferTo(convFile);
				} catch (Exception e) {
					e.printStackTrace();
				}
	 	          if(convFile.renameTo(new File("C:\\Users\\BBUDDI\\workspace\\CapStore\\WebContent\\images\\" + convFile.getName()))){
	 	     		System.out.println("File is moved successful!");
	 	     	   }else{
	 	     		System.out.println("File is failed to move!");
	 	     	   }
	                iQueryService.save(inventory);              
	            }
	        }
		return "view1";
	}
	
	@RequestMapping("/view")
	public String getFile(Model model,@RequestParam("s") int i) {
		String filepath=iQueryService.find(i);
		System.out.println(filepath);
		model.addAttribute("filepath",filepath);
		return "view";
	}
	
	@RequestMapping("/retrieve")
	public String retrievePassword(Model model,@RequestParam("emailId")String emailId) {
		String password=iQueryService.retrievePassword(emailId);
		model.addAttribute("password", password);
		System.out.println(password);
		return "index";
	}
	
	@RequestMapping("/change")
	public String changePassword(Model model,@RequestParam("previous_password")String password,
			@RequestParam("updated_password") String updatedPassword) {
		
		
		return "index";
	}
	
	
	*/
	
}
