package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IQueryDAO;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

@Service
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	IQueryDAO iQueryDAO;
	
	

	@Override
	public void plp() {
		iQueryDAO.plp();
	}



	@Override
	public Inventory getBusinessByProducts(String inventoryName) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Inventory getBusinessByMerchant(String merchantName) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Inventory getBusinessByProductCatagory(String inventoryType) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Inventory getBusinessByProductsAndMerchant(String inventoryName, Merchant merchant) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
