package com.cg.service;

import java.util.Date;
import java.util.List;

import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

public interface ICapgService {

	// List<QueryAnswers> getall();
void plp();


/*


void save(Inventory inventory);

String find(int i);

String retrievePassword(String emailId);





*/

public abstract List<SoldItems> getBusinessByProducts(String inventoryName,Date fromDate,Date toDate);
public abstract List<SoldItems> getBusinessByProductCatagory(String inventoryType,Date fromDate,Date toDate);
public abstract List<SoldItems> getBusinessByProductsAndMerchant(String inventoryType,String merchantName,Date fromDate,Date toDate);


}
