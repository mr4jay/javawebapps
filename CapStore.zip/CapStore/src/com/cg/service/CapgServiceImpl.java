package com.cg.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.CapgDAO;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

@Service
@Transactional
public class CapgServiceImpl implements ICapgService {

	@Autowired
	CapgDAO iQueryDAO;
	
	@Override
	public void plp() {
		iQueryDAO.plp();
	}

	@Override
	public List<SoldItems> getBusinessByProducts(String inventoryName,Date fromDate,Date toDate) {
		// TODO Auto-generated method stub
		return iQueryDAO.getBusinessByProducts(inventoryName, fromDate, toDate);
	}

	@Override
	public List<SoldItems> getBusinessByProductCatagory(String inventoryType,Date fromDate,Date toDate) {
		// TODO Auto-generated method stub
		return iQueryDAO.getBusinessByProductCatagory(inventoryType, fromDate, toDate);
	}

	@Override
	public List<SoldItems> getBusinessByProductsAndMerchant(String inventoryType, String merchantName,Date fromDate,Date toDate) {
		// TODO Auto-generated method stub
		return iQueryDAO.getBusinessByProductsAndMerchant(inventoryType, merchantName, fromDate, toDate);
	}
	
	
	
/*	
	
	
	

	@Override
	public void save(Inventory inventory) {
		iQueryDAO.save(inventory);
		
	}

	@Override
	public String find(int i) {
		return iQueryDAO.find(i);
	}

	@Override
	public String retrievePassword(String emailId) {
		return iQueryDAO.retrievePassword(emailId);
	}
	
	
	
	*/
	
	
	
	
	

	
}
