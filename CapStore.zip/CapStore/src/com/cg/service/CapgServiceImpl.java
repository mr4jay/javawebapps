package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.CapgDAO;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.ReturnedItems;
import com.cg.entities.SoldItems;

@Service
@Transactional
public class CapgServiceImpl implements ICapgService {

	@Autowired
	CapgDAO iQueryDAO;
	
	@Override
	public void plp() {
		iQueryDAO.plp();
	}

	@Override
	public List<SoldItems> getBusinessByProducts(String inventoryName,LocalDate fromDate,LocalDate toDate) {
		// TODO Auto-generated method stub
		return iQueryDAO.getBusinessByProducts(inventoryName, fromDate, toDate);
	}

	@Override
	public List<SoldItems> getBusinessByProductCatagory(String inventoryType,LocalDate fromDate,LocalDate toDate) {
		// TODO Auto-generated method stub
		return iQueryDAO.getBusinessByProductCatagory(inventoryType, fromDate, toDate);
	}

	@Override
	public List<SoldItems> getBusinessByProductsAndMerchant(String inventoryType, String merchantName,LocalDate fromDate,LocalDate toDate) {
		// TODO Auto-generated method stub
		return iQueryDAO.getBusinessByProductsAndMerchant(inventoryType, merchantName, fromDate, toDate);
	}
	
	
	//---------------------------------------------------------suddus:--------------------------------------------

	@Override
	public void refundMoney(int soldItemId) {
		// TODO Auto-generated method stub
		iQueryDAO.refundMoney(soldItemId);
	}
	
	//-------------------------------------------ash-----------------------------------------------------

	@Override
	public boolean updateInventoryByAdmin(int soldItemId, LocalDate date) {
		// TODO Auto-generated method stub
		 
		return iQueryDAO.updateInventoryByAdmin(soldItemId, date);
	}

	@Override
	public List<SoldItems> loadSoldItems() {
		// TODO Auto-generated method stub
		return iQueryDAO.loadSoldItems();
	}

	@Override
	public void returnItems(int soldItemId, LocalDate date) {
		// TODO Auto-generated method stub
		iQueryDAO.returnItems(soldItemId, date);
	}

	@Override
	public List<ReturnedItems> loadReturnedItems() {
		// TODO Auto-generated method stub
		return iQueryDAO.loadReturnedItems();
	}
	
	
}
