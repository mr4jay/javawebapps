package com.cg.entities;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class SoldItem implements Serializable{

	@Id
	private int soldItemId;
	@OneToOne
	@JoinColumn(name="customer_fk")
	private Customer customer;
	@OneToOne
	@JoinColumn(name="inventory_fk")
	private Inventory inventory;
	private String feedback;
	private Date soldDate;
	public int getSoldItemId() {
		return soldItemId;
	}
	public void setSoldItemId(int soldItemId) {
		this.soldItemId = soldItemId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Inventory getInventory() {
		return inventory;
	}
	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public Date getSoldDate() {
		return soldDate;
	}
	public void setSoldDate(Date soldDate) {
		this.soldDate = soldDate;
	}
	public SoldItem( Customer customer, Inventory inventory, String feedback, Date soldDate) {
		super();
		this.customer = customer;
		this.inventory = inventory;
		this.feedback = feedback;
		this.soldDate = soldDate;
	}
	public SoldItem() {
		super();
	}
	public SoldItem(int soldItemId, String feedback, Date soldDate) {
		super();
		this.soldItemId = soldItemId;
		this.feedback = feedback;
		this.soldDate = soldDate;
	}
	
	
	
	
}
