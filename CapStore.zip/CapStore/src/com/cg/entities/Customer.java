package com.cg.entities;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Customer implements Serializable{
	@Id
	@GeneratedValue
	private int customerId;
	@Column(unique=true)
	private String emailId;
	private String password;
	private String customerName;
	@ManyToMany
	@JoinTable(name="customer_wishlist", joinColumns= {@JoinColumn(name="customerid")},inverseJoinColumns= {@JoinColumn(name="wishlist")})
	private List<Inventory> wishList=new ArrayList<Inventory>();
	@ManyToMany
	@JoinTable(name="customer_cart", joinColumns= {@JoinColumn(name="customerid")},inverseJoinColumns= {@JoinColumn(name="cart")})
	private List<Inventory> cart=new ArrayList<Inventory>();
	private String address;
	private String cardNumber;
	@OneToMany(fetch=FetchType.LAZY)
	@JoinColumn(name="customer")
	private List<Coupons> coupons=new ArrayList<Coupons>();
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public List<Inventory> getWishList() {
		return wishList;
	}
	public void setWishList(Inventory wishList) {
		this.wishList.add(wishList);
	}
	public List<Inventory> getCart() {
		return cart;
	}
	public void setCart(Inventory cart) {
		this.cart.add(cart);
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String cardNumber() {
		return cardNumber;
	}
	public void setMoney(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public List<Coupons> getCoupons() {
		return coupons;
	}
	public void setCoupons(Coupons coupons) {
		this.coupons.add(coupons);
	}
	public Customer(String emailId, String password, String customerName, String address) {
		super();
		this.emailId = emailId;
		this.password = password;
		this.customerName = customerName;
		this.address = address;
	}
	public Customer() {
		super();
	}
	
	
}
