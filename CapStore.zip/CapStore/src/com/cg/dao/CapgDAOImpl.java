package com.cg.dao;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.ReturnedItems;
import com.cg.entities.SoldItems;

@Repository
public class CapgDAOImpl implements CapgDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	SoldItems solditems;

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd");
		admin.setMoney(10000.00);
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre");
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Merchant merchant1=new Merchant("afcsefq", "qer", "eeewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00);
	     Inventory inventory1=new Inventory("qwfwerqede", 500, 200.00, "edeq", 0.00);
	     Inventory inventory2=new Inventory("2ede", 500, 200.00, "edeq", 0.00);
	     
	     inventory.setMerchant(merchant);
	     inventory2.setMerchant(merchant);
	     inventory1.setMerchant(merchant1);
	     customer.setMoney(1000.00);
	     //customer.setCart(inventory);
	     SoldItems soldItems=new SoldItems(customer, inventory, "feedback", LocalDate.of(2019, 01, 9), "sattus", LocalDate.of(2019, 01, 9), 2);
	     SoldItems soldItems1=new SoldItems(customer, inventory1, "feedback", LocalDate.now(), "sattus", LocalDate.of(2019, 02, 4), 2);
	     SoldItems soldItems2=new SoldItems(customer, inventory2, "feedback", LocalDate.now(), "sattus", LocalDate.of(2019, 01, 15), 2);
	     //SoldItems soldItems2=new SoldItems(customer, inventory1, "feedback", new Date(), "sattus", new Date(2019, 04, 02), 2);
	     soldItems.setCustomer(customer);
	     soldItems.setInventory(inventory);
	     soldItems.setFeedback("fer");
	     ReturnedItems returnedItems = new ReturnedItems(LocalDate.now(), soldItems);
	     returnedItems.setReturnedToMerchant(0);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(merchant1);
	     entityManager.persist(inventory);
	     entityManager.persist(inventory1);
	     entityManager.persist(inventory2);
	     entityManager.persist(customer);
	     entityManager.persist(soldItems);
	     entityManager.persist(soldItems1);
	     entityManager.persist(soldItems2);
	     entityManager.persist(returnedItems);
	     //entityManager.persist(items);
	     entityManager.flush();
		
	}
	
	
	
	
	
	
	@Override
	public List<SoldItems> getBusinessByProducts(String inventoryName,LocalDate fromDate,LocalDate toDate ) {
		// TODO Auto-generated method stub
	/*
		
		System.out.println(fromDate+""+toDate);
		
		List<Inventory> inventories = new ArrayList<>();
		
		
		
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery("select s from SoldItems s", SoldItems.class);
		
		List<SoldItems>  allSoldItems = typedQuery.getResultList();
		
		for(SoldItems soldItem:allSoldItems) {
			
			if(soldItem.getInventory().getInventoryName().equals(inventoryName)) {
				
				
				
				if(soldItem.getSoldDate().before(toDate) && soldItem.getSoldDate().after(fromDate)) {
					
				}
				
				
				
				inventories.add(soldItem.getInventory());
				
			}
		
		}
		
		Iterator<Inventory> iterator = inventories.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		
		*/
		List<SoldItems> soldItemsList = new ArrayList<>();
		System.out.println("getBusinessByProducts Executing:.......");
		
		
		String sql = "select s from SoldItems s where s.inventory.inventoryName=:inventoryName";
		
		
		/*
		String sql = "select s from SoldItems s where (s.inventory.inventoryName=:inventoryName) and s.soldDate between'"+fromDate+"'and'"+toDate+"'";
		*/
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery(sql, SoldItems.class);
		typedQuery.setParameter("inventoryName", inventoryName);
		List<SoldItems> soldItems=typedQuery.getResultList();
		for(SoldItems soldItem:soldItems) {
			
			if(soldItem.getSoldDate().isBefore(toDate) && soldItem.getSoldDate().isAfter(fromDate)) {
				
				System.out.println(soldItem);
				soldItemsList.add(soldItem);
			}
			
			
		}
		
		
		
		
		
		return soldItemsList;
	}

	@Override
	public List<SoldItems> getBusinessByProductCatagory(String inventoryType,LocalDate fromDate,LocalDate toDate) {
		// TODO Auto-generated method stub
		
	/*
	 
	  System.out.println(fromDate+""+toDate);
		
		List<Inventory> inventories = new ArrayList<>();
		
		
		
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery("select s from SoldItems s", SoldItems.class);
		
		List<SoldItems>  allSoldItems = typedQuery.getResultList();
		
		for(SoldItems soldItem:allSoldItems) {
			
			if(soldItem.getInventory().getInventoryType().equals(inventoryType)) {
				
				
				
				if(soldItem.getSoldDate().before(toDate) && soldItem.getSoldDate().after(fromDate)) {
					
				}
				
				
				
				inventories.add(soldItem.getInventory());
				
			}
		
		}
		
		Iterator<Inventory> iterator = inventories.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		*/
		List<SoldItems> soldItemsList = new ArrayList<>();
		System.out.println("getBusinessByProductCatagory Executing:.......");
		
		/*
		String sql = "select s from SoldItems s where (s.inventory.inventoryType=:inventoryType) and s.soldDate between'"+fromDate+"'and'"+toDate+"'";
		*/
		
		String sql = "select s from SoldItems s where s.inventory.inventoryType=:inventoryType";
		
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery(sql, SoldItems.class);
		typedQuery.setParameter("inventoryType", inventoryType);
		List<SoldItems> soldItems=typedQuery.getResultList();
		for(SoldItems soldItem:soldItems) {
			
			if(soldItem.getSoldDate().isBefore(toDate) && soldItem.getSoldDate().isAfter(fromDate)) {

				System.out.println(soldItem);
				
				soldItemsList.add(soldItem);
				
			}
			
		}
		
		
		
		
		return soldItemsList;
	}

	@Override
	public List<SoldItems> getBusinessByProductsAndMerchant(String inventoryType, String merchantName,LocalDate fromDate,LocalDate toDate) {
		// TODO Auto-generated method stub
		
	/*System.out.println(fromDate+""+toDate);
		
		List<Merchant> merchants = new ArrayList<>();
		
		
		
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery("select s from SoldItems s", SoldItems.class);
		
		List<SoldItems>  allSoldItems = typedQuery.getResultList();
		
		for(SoldItems soldItem:allSoldItems) {
			
			if(soldItem.getInventory().getInventoryName().equals(inventoryName) &&
					soldItem.getInventory().getMerchant().getMerchantName().equals(merchantName)) {
				
				
				
				if(soldItem.getSoldDate().before(toDate) && soldItem.getSoldDate().after(fromDate)) {
					
				}
				
				
				
				merchants.add(soldItem.getInventory().getMerchant());
				
			}
		
		}
		
		Iterator<Merchant> iterator = merchants.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
	*/
		List<SoldItems> soldItemsList = new ArrayList<>();
		
		System.out.println("getBusinessByProductsAndMerchant Executing:.......");
		
		
		String sql = "select s from SoldItems s where s.inventory.merchant.merchantName=:merchantName"
				+ " and s.inventory.inventoryType=:inventoryType";
		
		
		/*
		String sql = "select s from SoldItems s where (s.inventory.merchant.merchantName=:merchantName)"
				+ "and (s.inventory.inventoryType=:inventoryType) and s.soldDate between'"+fromDate+"'and'"+toDate+"'";
		*/
		
		
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery(sql, SoldItems.class);
		
		typedQuery.setParameter("merchantName", merchantName);
		typedQuery.setParameter("inventoryType", inventoryType);
		List<SoldItems> soldItems=typedQuery.getResultList();
		
		for(SoldItems soldItem:soldItems) {
			
			if(soldItem.getSoldDate().isBefore(toDate) && soldItem.getSoldDate().isAfter(fromDate)) {

				System.out.println(soldItem);
				
				soldItemsList.add(soldItem);
				
			}
			
		}
		return soldItemsList;
	}
	
	
	//suddus:
	
	
	@Override
	public void refundMoney(int soldItemId) {
	// TODO Auto-generated method stub
	SoldItems soldItem=entityManager.find(SoldItems.class, soldItemId);
	Admin admin = entityManager.find(Admin.class, 1);
	Customer customer = entityManager.find(Customer.class, soldItem.getCustomer().getCustomerId());
	/*int mId=soldItem.getInventory().getMerchant().getMerchantId();
	System.out.println(mId);*/
	int inventoryId = soldItem.getInventory().getInventoryId();
	
	Inventory inventory =entityManager.find(Inventory.class, inventoryId);
	Admin updatedAdmin = admin;
	Customer updatedCustomer = customer;
	updatedAdmin.setMoney(admin.getMoney()-inventory.getPrice());
	updatedCustomer.setMoney(customer.getMoney()+inventory.getPrice());
	
	entityManager.persist(updatedCustomer);
	entityManager.persist(updatedAdmin);
	
	}

	//----------------------------------------------------ash--------------------------------------------------------------------//
	

	@Override
	public void returnItems(int soldItemId, LocalDate date) {
		// TODO Auto-generated method stub
		SoldItems soldItem=entityManager.find(SoldItems.class, soldItemId);
		
		
		
		
		ReturnedItems returnedItems = new ReturnedItems();
		returnedItems.setSoldItems(soldItem);
		returnedItems.setReturnedDate(date);
		entityManager.persist(returnedItems);
		entityManager.flush();
		
	}
	

	@Override
	public boolean updateInventoryByAdmin(int soldItemId, LocalDate date) 
	{	
		//
		String str = "select r from ReturnedItems r where r.soldItems.soldItemId=:soldItemId";
		TypedQuery<ReturnedItems> typedQuery = entityManager.createQuery(str, ReturnedItems.class);
		typedQuery.setParameter("soldItemId", soldItemId);
		ReturnedItems returnitems = (ReturnedItems) typedQuery.getResultList().get(0);
		SoldItems soldItem = returnitems.getSoldItems();
		int inventoryId = soldItem.getInventory().getInventoryId();
		Inventory inventory =entityManager.find(Inventory.class, inventoryId);
		
		
		Period period = soldItem.getSoldDate().until(returnitems.getReturnedDate());
		int returnExpiry=period.getDays();
		
		if (returnExpiry <= 30) {
			
			Inventory inventoryUpdated = inventory;
			SoldItems soldItemsUpdated = soldItem;
			ReturnedItems returnedItemsUpdated = returnitems;
			
			inventoryUpdated.setQuantity(inventory.getQuantity()+1);
			soldItemsUpdated.setReturnedToAdmin(1);
			returnedItemsUpdated.setReturnedToMerchant(1);
			entityManager.persist(inventoryUpdated);
			entityManager.persist(soldItemsUpdated);
			entityManager.persist(returnedItemsUpdated);
			
			entityManager.flush();
			
			return true;
			
		}
		

		
		return false;
	
	}


	@Override
	public List<SoldItems> loadSoldItems() {
		// TODO Auto-generated method stub
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery("select s from SoldItems s", SoldItems.class);
		return typedQuery.getResultList();
	}
	
	@Override
	public List<ReturnedItems> loadReturnedItems() {
		// TODO Auto-generated method stub
		TypedQuery<ReturnedItems> typedQuery = entityManager.createQuery("select r from ReturnedItems r", ReturnedItems.class);
		return typedQuery.getResultList();
	}


	
	
	
	
	/*
	

	@Override
	public void save(Inventory inventory) {
		entityManager.persist(inventory);
		entityManager.flush();
	}

	@Override
	public String find(int i) {
		Inventory inventory=entityManager.find(Inventory.class,i);
		return inventory.getFileName();
	}

	@Override
	public String retrievePassword(String emailId) {
		//TypedQuery<Admin> query=entityManager.createQuery("select a from Admin a where a.emailId="+emailId, Admin.class);
		String selectQuery = "from Admin a where a.emailId=:emailId";
		Query query = entityManager.createQuery(selectQuery);
		query.setParameter("emailId", emailId);
		List<Admin> admins=query.getResultList();
		return admins.get(0).getPassword();
	}
	
	
	
	
	*/
	
	
}
