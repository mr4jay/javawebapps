package com.cg.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

import oracle.net.aso.i;

@Repository
public class CapgDAOImpl implements CapgDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	SoldItems solditems;

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd");
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre");
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Merchant merchant1=new Merchant("afcsefq", "qer", "eeewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00);
	     Inventory inventory1=new Inventory("qwfwerqede", 500, 200.00, "edeq", 0.00);
	     Inventory inventory2=new Inventory("2ede", 500, 200.00, "edeq", 0.00);
	     inventory.setMerchant(merchant);
	     inventory2.setMerchant(merchant);
	     inventory1.setMerchant(merchant1);
	     customer.setCart(inventory);
	     SoldItems soldItems=new SoldItems(customer, inventory, "feedback", new Date(), "sattus", new Date(2019, 04, 02), 2);
	     SoldItems soldItems1=new SoldItems(customer, inventory1, "feedback", new Date(), "sattus", new Date(2019, 04, 02), 2);
	     SoldItems soldItems2=new SoldItems(customer, inventory2, "feedback", new Date(), "sattus", new Date(2019, 04, 02), 2);
	     //SoldItems soldItems2=new SoldItems(customer, inventory1, "feedback", new Date(), "sattus", new Date(2019, 04, 02), 2);
	     soldItems.setCustomer(customer);
	     soldItems.setInventory(inventory);
	     soldItems.setFeedback("fer");
	     soldItems.setSoldDate(new Date());
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(merchant1);
	     entityManager.persist(inventory);
	     entityManager.persist(inventory1);
	     entityManager.persist(inventory2);
	     entityManager.persist(customer);
	     entityManager.persist(soldItems);
	     entityManager.persist(soldItems1);
	     entityManager.persist(soldItems2);
	     //entityManager.persist(items);
	     entityManager.flush();
		
	}
	
	
	
	
	
	
	@Override
	public List<SoldItems> getBusinessByProducts(String inventoryName,Date fromDate,Date toDate ) {
		// TODO Auto-generated method stub
	/*
		
		System.out.println(fromDate+""+toDate);
		
		List<Inventory> inventories = new ArrayList<>();
		
		
		
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery("select s from SoldItems s", SoldItems.class);
		
		List<SoldItems>  allSoldItems = typedQuery.getResultList();
		
		for(SoldItems soldItem:allSoldItems) {
			
			if(soldItem.getInventory().getInventoryName().equals(inventoryName)) {
				
				
				
				if(soldItem.getSoldDate().before(toDate) && soldItem.getSoldDate().after(fromDate)) {
					
				}
				
				
				
				inventories.add(soldItem.getInventory());
				
			}
		
		}
		
		Iterator<Inventory> iterator = inventories.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		
		*/
		List<SoldItems> soldItemsList = new ArrayList<>();
		System.out.println("sdfgdf");
		String sql = "select s from SoldItems s where s.inventory.inventoryName=:inventoryName";
		/*
		String sql1 = "select s from SoldItems s where s.inventory.inventoryName=:inventoryName and s.soldDate between'"+fromDate+"'and'"+toDate+"'";
		*/
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery(sql, SoldItems.class);
		typedQuery.setParameter("inventoryName", inventoryName);
		List<SoldItems> soldItems=typedQuery.getResultList();
		for(SoldItems soldItem:soldItems) {
			
			if(soldItem.getSoldDate().before(toDate) && soldItem.getSoldDate().after(fromDate)) {
				
			}
			
			System.out.println(soldItem);
			
			soldItemsList.add(soldItem);
		}
		
		
		
		
		
		return soldItemsList;
	}

	@Override
	public List<SoldItems> getBusinessByProductCatagory(String inventoryType,Date fromDate,Date toDate) {
		// TODO Auto-generated method stub
		
	/*
	 
	  System.out.println(fromDate+""+toDate);
		
		List<Inventory> inventories = new ArrayList<>();
		
		
		
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery("select s from SoldItems s", SoldItems.class);
		
		List<SoldItems>  allSoldItems = typedQuery.getResultList();
		
		for(SoldItems soldItem:allSoldItems) {
			
			if(soldItem.getInventory().getInventoryType().equals(inventoryType)) {
				
				
				
				if(soldItem.getSoldDate().before(toDate) && soldItem.getSoldDate().after(fromDate)) {
					
				}
				
				
				
				inventories.add(soldItem.getInventory());
				
			}
		
		}
		
		Iterator<Inventory> iterator = inventories.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		*/
		List<SoldItems> soldItemsList = new ArrayList<>();
		System.out.println("sdfgdf");
		/*
		String sql = "select s from SoldItems s where s.inventory.inventoryType=:inventoryType and s.soldDate between'"+fromDate+"'and'"+toDate+"'";
		*/
		String sql = "select s from SoldItems s where s.inventory.inventoryType=:inventoryType";
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery(sql, SoldItems.class);
		typedQuery.setParameter("inventoryType", inventoryType);
		List<SoldItems> soldItems=typedQuery.getResultList();
		for(SoldItems soldItem:soldItems) {
			
			if(soldItem.getSoldDate().before(toDate) && soldItem.getSoldDate().after(fromDate)) {
				
			}
			
			System.out.println(soldItem);
			
			soldItemsList.add(soldItem);
			
		}
		
		
		
		
		return soldItemsList;
	}

	@Override
	public List<SoldItems> getBusinessByProductsAndMerchant(String inventoryType, String merchantName,Date fromDate,Date toDate) {
		// TODO Auto-generated method stub
		
	/*System.out.println(fromDate+""+toDate);
		
		List<Merchant> merchants = new ArrayList<>();
		
		
		
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery("select s from SoldItems s", SoldItems.class);
		
		List<SoldItems>  allSoldItems = typedQuery.getResultList();
		
		for(SoldItems soldItem:allSoldItems) {
			
			if(soldItem.getInventory().getInventoryName().equals(inventoryName) &&
					soldItem.getInventory().getMerchant().getMerchantName().equals(merchantName)) {
				
				
				
				if(soldItem.getSoldDate().before(toDate) && soldItem.getSoldDate().after(fromDate)) {
					
				}
				
				
				
				merchants.add(soldItem.getInventory().getMerchant());
				
			}
		
		}
		
		Iterator<Merchant> iterator = merchants.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
	*/
		List<SoldItems> soldItemsList = new ArrayList<>();
		
		System.out.println("sdfgdf");
		
		String sql = "select s from SoldItems s where s.inventory.merchant.merchantName=:merchantName"
				+ " and s.inventory.inventoryType=:inventoryType";
		
		/*
		String sql = "select s from SoldItems s where s.inventory.merchant.merchantName=:merchantName"
				+ "and s.inventory.inventoryType=:inventoryType and s.soldDate between'"+fromDate+"'and'"+toDate+"'";
		
		*/
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery(sql, SoldItems.class);
		
		typedQuery.setParameter("merchantName", merchantName);
		typedQuery.setParameter("inventoryType", inventoryType);
		List<SoldItems> soldItems=typedQuery.getResultList();
		for(SoldItems soldItem:soldItems) {
			

			if(soldItem.getSoldDate().before(toDate) && soldItem.getSoldDate().after(fromDate)) {
				
			}
			
			System.out.println(soldItem);
			
			soldItemsList.add(soldItem);
			
			
		}
		return soldItemsList;
	}


	
	
	
	
	/*
	

	@Override
	public void save(Inventory inventory) {
		entityManager.persist(inventory);
		entityManager.flush();
	}

	@Override
	public String find(int i) {
		Inventory inventory=entityManager.find(Inventory.class,i);
		return inventory.getFileName();
	}

	@Override
	public String retrievePassword(String emailId) {
		//TypedQuery<Admin> query=entityManager.createQuery("select a from Admin a where a.emailId="+emailId, Admin.class);
		String selectQuery = "from Admin a where a.emailId=:emailId";
		Query query = entityManager.createQuery(selectQuery);
		query.setParameter("emailId", emailId);
		List<Admin> admins=query.getResultList();
		return admins.get(0).getPassword();
	}
	
	
	
	
	*/
	
	
}
