package com.cg.dao;

import java.time.LocalDate;

import java.util.List;

import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.ReturnedItems;
import com.cg.entities.SoldItems;

public interface CapgDAO {
	
	void plp();

/*	
	
	void save(Inventory inventory);

	String find(int i);

	String retrievePassword(String emailId);
	
	
	
	*/
	
	public abstract List<SoldItems> getBusinessByProducts(String inventoryName,LocalDate fromDate,LocalDate toDate);
	public abstract List<SoldItems> getBusinessByProductCatagory(String inventoryType,LocalDate fromDate,LocalDate toDate);
	public abstract List<SoldItems> getBusinessByProductsAndMerchant(String inventoryType,String merchantName,LocalDate fromDate,LocalDate toDate);
	
	//suddus:
	public void refundMoney(int soldItemId);
	
	//ash
	
	public abstract List<SoldItems> loadSoldItems();
	
	public abstract boolean updateInventoryByAdmin(int soldItemId, LocalDate date);

	public abstract void returnItems(int soldItemId, LocalDate date);
	
	public List<ReturnedItems> loadReturnedItems() ;

	
	
}
